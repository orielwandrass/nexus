import React from 'react';
import { X, AlertCircle, CheckCircle, Info } from 'lucide-react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  message: string;
  type?: 'success' | 'error' | 'info';
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, message, type = 'info' }) => {
  if (!isOpen) return null;

  const icons = {
    success: <CheckCircle className="w-10 h-10 text-green-500 mb-3" />,
    error: <AlertCircle className="w-10 h-10 text-red-500 mb-3" />,
    info: <Info className="w-10 h-10 text-blue-500 mb-3" />
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      ></div>

      {/* Modal Content */}
      <div className="relative glass-card rounded-2xl p-6 w-full max-w-sm text-center transform transition-all animate-fade-in-up border border-white/20 dark:border-zinc-700">
        <button 
          onClick={onClose}
          className="absolute top-3 right-3 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-colors"
        >
          <X size={20} />
        </button>

        <div className="flex flex-col items-center">
          {icons[type]}
          <h3 className="text-xl font-bold text-zinc-800 dark:text-white mb-2">{title}</h3>
          <p className="text-zinc-600 dark:text-zinc-300 mb-6">{message}</p>
          
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl font-medium text-white shadow-lg transition-transform active:scale-95 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
          >
            Entendido
          </button>
        </div>
      </div>
    </div>
  );
};

export default Modal;