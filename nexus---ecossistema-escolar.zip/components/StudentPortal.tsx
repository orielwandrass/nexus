import React from 'react';
import { Student, Grade, Attendance } from '../types';
import { MOCK_GRADES, MOCK_ATTENDANCE, SUBJECTS, SCHOOLS, SECRETARIATS } from '../constants';
import { Download, CheckCircle, XCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface StudentPortalProps {
  student: Student;
  onLogout: () => void;
  darkMode?: boolean;
}

const StudentPortal: React.FC<StudentPortalProps> = ({ student, onLogout, darkMode }) => {
  const school = SCHOOLS.find(s => s.id === student.schoolId);
  const secretariat = SECRETARIATS.find(s => s.id === student.secretariatId);

  const myGrades = MOCK_GRADES.filter(g => g.studentId === student.id);
  const myAttendance = MOCK_ATTENDANCE.filter(a => a.studentId === student.id);

  // Calculate stats
  const totalClasses = 100;
  const absences = myAttendance.filter(a => !a.present).length;
  const presencePercentage = ((totalClasses - absences) / totalClasses) * 100;

  const chartData = SUBJECTS.map(subj => {
    const grade = myGrades.find(g => g.subject === subj.name && g.period === 1);
    return {
      name: subj.name,
      nota: grade ? grade.value : 0,
    };
  });

  return (
    <div className="min-h-screen text-zinc-900 dark:text-zinc-100 font-sans transition-colors">
      {/* Header */}
      <header className="glass border-b border-white/20 sticky top-0 z-30">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-lg font-bold bg-gradient-to-r from-blue-700 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 bg-clip-text text-transparent">{secretariat?.name}</h1>
            <p className="text-sm text-zinc-500 dark:text-zinc-400">{school?.name}</p>
          </div>
          <button 
            onClick={onLogout}
            className="px-4 py-2 rounded-lg text-sm font-medium bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/40 transition"
          >
            Sair
          </button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Student ID Card */}
        <div className="glass-card rounded-2xl p-8 mb-8 border-l-8 border-blue-500 flex flex-col md:flex-row justify-between items-start md:items-center animate-fade-in-up">
          <div>
            <h2 className="text-3xl font-bold text-zinc-800 dark:text-white mb-1">{student.name}</h2>
            <div className="mt-3 flex flex-wrap gap-4 text-sm text-zinc-600 dark:text-zinc-300">
               <span className="bg-zinc-100 dark:bg-zinc-800 px-3 py-1 rounded-full border border-zinc-200 dark:border-zinc-700">Matrícula: <strong>{student.matricula}</strong></span>
               <span className="bg-zinc-100 dark:bg-zinc-800 px-3 py-1 rounded-full border border-zinc-200 dark:border-zinc-700">Turma: <strong>{student.className}</strong></span>
               <span className="bg-zinc-100 dark:bg-zinc-800 px-3 py-1 rounded-full border border-zinc-200 dark:border-zinc-700">Nascimento: <strong>{new Date(student.birthDate).toLocaleDateString('pt-BR')}</strong></span>
            </div>
          </div>
          <div className="mt-6 md:mt-0 text-center">
            <div className={`text-5xl font-bold ${presencePercentage >= 75 ? 'text-emerald-500' : 'text-red-500'} drop-shadow-sm`}>
              {presencePercentage}%
            </div>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 uppercase tracking-widest font-semibold mt-1">Frequência Global</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
          {/* Boletim */}
          <div className="lg:col-span-2 glass-card rounded-2xl overflow-hidden shadow-lg dark:shadow-black/20">
            <div className="px-6 py-5 border-b border-zinc-200/50 dark:border-zinc-700/50 flex justify-between items-center bg-white/40 dark:bg-zinc-800/40">
              <h3 className="font-bold text-zinc-800 dark:text-white flex items-center gap-2">
                 Boletim Escolar <span className="text-xs bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 px-2 py-0.5 rounded">1º Bimestre</span>
              </h3>
              <button className="flex items-center text-blue-600 dark:text-blue-400 hover:underline text-sm font-medium">
                <Download className="w-4 h-4 mr-1" /> Baixar PDF
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left text-zinc-600 dark:text-zinc-300">
                <thead className="text-xs text-zinc-500 dark:text-zinc-400 uppercase bg-zinc-50/50 dark:bg-zinc-800/50 border-b border-zinc-200/50 dark:border-zinc-700/50">
                  <tr>
                    <th className="px-6 py-4">Disciplina</th>
                    <th className="px-6 py-4 text-center">Nota (0-10)</th>
                    <th className="px-6 py-4 text-center">Faltas</th>
                    <th className="px-6 py-4 text-center">Situação</th>
                  </tr>
                </thead>
                <tbody>
                  {SUBJECTS.map((subj) => {
                    const grade = myGrades.find(g => g.subject === subj.name && g.period === 1);
                    const status = (grade?.value || 0) >= 6 ? 'Aprovado' : 'Recuperação';
                    
                    return (
                      <tr key={subj.id} className="border-b border-zinc-100 dark:border-zinc-700/50 hover:bg-zinc-50/30 dark:hover:bg-zinc-800/30 transition-colors">
                        <td className="px-6 py-4 font-semibold text-zinc-800 dark:text-zinc-200">{subj.name}</td>
                        <td className="px-6 py-4 text-center">
                          <span className={`px-3 py-1 rounded-lg font-bold shadow-sm ${
                            (grade?.value || 0) >= 6 ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
                          }`}>
                            {grade ? grade.value.toFixed(1) : '-'}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-center">{Math.floor(Math.random() * 5)}</td>
                        <td className="px-6 py-4 text-center">
                           <span className={`text-xs font-bold mr-2 px-2.5 py-1 rounded-full ${
                             status === 'Aprovado' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400' : 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400'
                           }`}>
                             {status}
                           </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Performance Chart */}
          <div className="glass-card rounded-2xl p-6 shadow-lg">
            <h3 className="font-bold text-zinc-800 dark:text-white mb-6">Desempenho Visual</h3>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={darkMode ? '#334155' : '#e2e8f0'} />
                  <XAxis dataKey="name" hide />
                  <YAxis domain={[0, 10]} stroke={darkMode ? '#94a3b8' : '#64748b'} fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip 
                    cursor={{fill: darkMode ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)'}}
                    contentStyle={{ 
                        backgroundColor: darkMode ? '#18181b' : '#fff', 
                        borderRadius: '12px', 
                        border: 'none', 
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' 
                    }} 
                  />
                  <Bar dataKey="nota" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-6 space-y-3">
               {chartData.map((d, i) => (
                 <div key={i} className="flex justify-between text-xs items-center">
                    <span className="text-zinc-500 dark:text-zinc-400 font-medium">{d.name}</span>
                    <div className="flex-1 mx-3 h-1 bg-zinc-100 dark:bg-zinc-700 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500 rounded-full" style={{ width: `${d.nota * 10}%` }}></div>
                    </div>
                    <span className="font-bold text-zinc-700 dark:text-zinc-200">{d.nota.toFixed(1)}</span>
                 </div>
               ))}
            </div>
          </div>
        </div>

        {/* Latest Attendance */}
        <div className="mt-6 glass-card rounded-2xl p-6 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
          <h3 className="font-bold text-zinc-800 dark:text-white mb-4">Frequência Recente</h3>
          <div className="flex space-x-4 overflow-x-auto pb-2 scrollbar-hide">
            {[...Array(5)].map((_, i) => {
                const date = new Date();
                date.setDate(date.getDate() - i);
                const isPresent = Math.random() > 0.1; // Random attendance for demo
                return (
                    <div key={i} className="flex flex-col items-center min-w-[90px] p-4 border border-zinc-200 dark:border-zinc-700 rounded-xl bg-white/40 dark:bg-zinc-800/40">
                        <span className="text-xs text-zinc-500 dark:text-zinc-400 mb-2 font-medium">{date.getDate()}/{date.getMonth() + 1}</span>
                        {isPresent ? 
                            <CheckCircle className="w-8 h-8 text-emerald-500 drop-shadow-sm" /> : 
                            <XCircle className="w-8 h-8 text-red-500 drop-shadow-sm" />
                        }
                        <span className="text-xs font-bold mt-2 text-zinc-700 dark:text-zinc-300">{isPresent ? 'Presente' : 'Falta'}</span>
                    </div>
                )
            })}
          </div>
        </div>
      </main>
    </div>
  );
};

export default StudentPortal;