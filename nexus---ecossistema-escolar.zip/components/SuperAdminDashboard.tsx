import React, { useState, useEffect } from 'react';
import { User, Secretariat } from '../types';
import { getAllSecretariats, saveSecretariat, toggleSecretariatStatus } from '../services/dataService';
import { Plus, MapPin, Building2, Save, X, Loader2, AlertTriangle, Pencil, KeyRound, Shield, Check, ToggleLeft, ToggleRight, Lock } from 'lucide-react';

interface SuperAdminDashboardProps {
  user: User;
  showToast: (title: string, msg: string, type: 'success' | 'error' | 'info') => void;
  onLogout: () => void;
}

// Extensão da interface para incluir o email admin na listagem local
interface ExtendedSecretariat extends Secretariat {
    adminEmail?: string;
}

const SuperAdminDashboard: React.FC<SuperAdminDashboardProps> = ({ user, showToast, onLogout }) => {
  const [secretariats, setSecretariats] = useState<ExtendedSecretariat[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Controle do Formulário
  const [showForm, setShowForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Campos do Formulário
  const [formData, setFormData] = useState({
      name: '',
      city: '',
      state: '',
      adminEmail: 'orielwandrass@gmail.com',
      adminPassword: '123456' // Campo de senha
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    loadSecretariats();
  }, []);

  const loadSecretariats = async () => {
    setIsLoading(true);
    const data = await getAllSecretariats();
    setSecretariats(data);
    setIsLoading(false);
  };

  const generateSafeId = (city: string) => {
    const slug = city
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, '-');
    return `sec-${slug}`;
  };

  const handleOpenCreate = () => {
      setFormData({ name: '', city: '', state: '', adminEmail: '', adminPassword: '' });
      setIsEditing(false);
      setEditingId(null);
      setShowForm(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenEdit = (sec: ExtendedSecretariat) => {
      setFormData({
          name: sec.name,
          city: sec.city,
          state: sec.state,
          adminEmail: sec.adminEmail || '',
          adminPassword: '' // Senha começa vazia na edição (só muda se preencher)
      });
      setIsEditing(true);
      setEditingId(sec.id);
      setShowForm(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.city || !formData.state || !formData.adminEmail) {
        showToast('Campos Incompletos', 'Nome, cidade, estado e e-mail são obrigatórios.', 'info');
        return;
    }
    
    // Validação de senha na criação
    if (!isEditing && !formData.adminPassword) {
        showToast('Senha Obrigatória', 'Defina uma senha inicial para a nova secretaria.', 'info');
        return;
    }

    setIsSubmitting(true);

    const id = isEditing && editingId ? editingId : generateSafeId(formData.city);
    
    if (!isEditing && secretariats.some(s => s.id === id)) {
        showToast('Conflito', 'Já existe uma secretaria para esta cidade. Use a edição.', 'error');
        setIsSubmitting(false);
        return;
    }

    // Preserva o status atual se estiver editando, ou define como true (ativo) se criando
    const currentActiveStatus = isEditing 
        ? secretariats.find(s => s.id === id)?.active ?? true 
        : true;

    const secretariatData: Secretariat = {
        id,
        name: formData.name,
        city: formData.city,
        state: formData.state.toUpperCase(),
        logoUrl: `https://ui-avatars.com/api/?name=${formData.city.replace(' ', '+')}&background=0D8ABC&color=fff&size=200`,
        active: currentActiveStatus
    };

    const result = await saveSecretariat(secretariatData, formData.adminEmail, formData.adminPassword, isEditing);
    
    if (result.success) {
        showToast('Sucesso', isEditing ? 'Dados atualizados com sucesso.' : 'Nova secretaria criada e credenciais definidas.', 'success');
        setShowForm(false);
        loadSecretariats();
    } else {
        showToast('Erro', result.message || 'Falha ao salvar dados.', 'error');
    }
    setIsSubmitting(false);
  };

  const handleToggleStatus = async (id: string, name: string, currentStatus: boolean) => {
    const action = currentStatus ? "DESATIVAR" : "ATIVAR";
    const consequence = currentStatus 
        ? "Ela NÃO aparecerá mais nas buscas e o acesso será BLOQUEADO." 
        : "Ela voltará a aparecer nas buscas e o acesso será liberado.";

    if (confirm(`Confirmar alteração de status?\n\nVocê vai ${action} a ${name}.\n\n${consequence}`)) {
        const success = await toggleSecretariatStatus(id, currentStatus);
        if (success) {
            showToast('Status Alterado', `Secretaria ${currentStatus ? 'desativada' : 'ativada'} com sucesso.`, 'success');
            loadSecretariats();
        } else {
            showToast('Erro', 'Falha ao atualizar status.', 'error');
        }
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans p-4 md:p-8">
       {/* Top Bar */}
       <header className="flex flex-col md:flex-row justify-between items-center mb-8 border-b border-zinc-800 pb-6 gap-4 animate-fade-in-up">
           <div>
               <h1 className="text-2xl md:text-3xl font-bold text-white flex items-center gap-3">
                   <Shield className="text-emerald-500" />
                   NEXUS MASTER
               </h1>
               <p className="text-zinc-400 text-sm mt-1 font-mono">
                   Ambiente de Controle Global (SaaS)
               </p>
           </div>
           <div className="flex items-center gap-4 bg-zinc-900 p-2 rounded-xl border border-zinc-800 shadow-xl">
               <div className="text-right hidden sm:block px-2">
                   <p className="font-bold text-white text-sm">{user.name}</p>
                   <p className="text-[10px] text-emerald-400 font-mono uppercase tracking-widest">Super Admin</p>
               </div>
               <button onClick={onLogout} className="px-4 py-2 bg-red-500/10 text-red-400 hover:bg-red-500/20 rounded-lg transition text-xs font-bold uppercase tracking-wider border border-red-500/20">
                   Sair
               </button>
           </div>
       </header>

       {/* Main Card */}
       <div className="bg-zinc-900 rounded-3xl border border-zinc-800 overflow-hidden shadow-2xl animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
           
           {/* Action Bar */}
           <div className="p-6 border-b border-zinc-800 flex flex-col md:flex-row justify-between items-center gap-4 bg-zinc-900/50">
               <div>
                   <h2 className="text-xl font-bold flex items-center gap-2 text-white">
                       <Building2 className="text-blue-500" /> Secretarias de Educação
                   </h2>
                   <p className="text-xs text-zinc-500 mt-1">Gerencie as entidades, credenciais e status de acesso.</p>
               </div>
               {!showForm && (
                   <button 
                    onClick={handleOpenCreate}
                    className="w-full md:w-auto bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-3 rounded-xl flex items-center justify-center gap-2 text-sm font-bold transition shadow-lg shadow-emerald-900/20 transform hover:-translate-y-0.5"
                   >
                       <Plus size={18} /> Adicionar Nova Entidade
                   </button>
               )}
           </div>

           {/* Create/Edit Form */}
           {showForm && (
               <div className="p-8 bg-zinc-800/50 border-b border-zinc-700 animate-fade-in-up">
                   <div className="flex justify-between items-start mb-6">
                        <h3 className="text-lg font-bold text-white flex items-center gap-2">
                            {isEditing ? <Pencil className="text-amber-400" size={20} /> : <Plus className="text-emerald-400" size={20} />}
                            {isEditing ? 'Editar Secretaria & Acesso' : 'Nova Secretaria & Acesso'}
                        </h3>
                        <button onClick={() => setShowForm(false)} className="text-zinc-500 hover:text-white transition">
                            <X size={24} />
                        </button>
                   </div>

                   <form onSubmit={handleSave} className="grid grid-cols-1 md:grid-cols-12 gap-6">
                       {/* Entity Data */}
                       <div className="md:col-span-12">
                           <p className="text-xs font-bold text-blue-400 uppercase tracking-widest mb-4 border-b border-zinc-700 pb-2">Dados da Entidade</p>
                       </div>
                       
                       <div className="md:col-span-6">
                           <label className="block text-xs font-bold text-zinc-400 mb-2">Nome Oficial da Secretaria</label>
                           <input 
                            required
                            value={formData.name}
                            onChange={e => setFormData({...formData, name: e.target.value})}
                            className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition" 
                            placeholder="Ex: Secretaria Mun. de Educação..."
                           />
                       </div>
                       <div className="md:col-span-4">
                           <label className="block text-xs font-bold text-zinc-400 mb-2">Cidade</label>
                           <input 
                            required
                            value={formData.city}
                            onChange={e => setFormData({...formData, city: e.target.value})}
                            className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:border-blue-500 outline-none transition" 
                            placeholder="Ex: Caxias"
                           />
                       </div>
                       <div className="md:col-span-2">
                           <label className="block text-xs font-bold text-zinc-400 mb-2">UF</label>
                           <input 
                            required
                            maxLength={2}
                            value={formData.state}
                            onChange={e => setFormData({...formData, state: e.target.value.toUpperCase()})}
                            className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:border-blue-500 outline-none transition" 
                            placeholder="MA"
                           />
                       </div>

                       {/* Access Data */}
                       <div className="md:col-span-12 mt-2">
                           <p className="text-xs font-bold text-emerald-400 uppercase tracking-widest mb-4 border-b border-zinc-700 pb-2 flex items-center gap-2">
                               <KeyRound size={14} /> Credenciais de Acesso (Login)
                           </p>
                       </div>

                       <div className="md:col-span-6">
                           <label className="block text-xs font-bold text-zinc-400 mb-2">E-mail do Administrador (Secretário)</label>
                           <div className="relative">
                               <input 
                                required
                                type="email"
                                value={formData.adminEmail}
                                onChange={e => setFormData({...formData, adminEmail: e.target.value})}
                                className="w-full bg-zinc-950 border border-zinc-700 rounded-xl pl-10 pr-4 py-3 text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition" 
                                placeholder="admin@educacao.gov.br"
                               />
                               <KeyRound size={16} className="absolute left-3 top-3.5 text-zinc-500" />
                           </div>
                           <p className="text-[10px] text-zinc-500 mt-2 ml-1">
                               * Login para acessar o painel da secretaria.
                           </p>
                       </div>

                       <div className="md:col-span-6">
                           <label className="block text-xs font-bold text-zinc-400 mb-2">
                               {isEditing ? 'Redefinir Senha de Acesso (Opcional)' : 'Senha de Acesso Inicial'}
                           </label>
                           <div className="relative">
                               <input 
                                required={!isEditing}
                                type="text" 
                                value={formData.adminPassword}
                                onChange={e => setFormData({...formData, adminPassword: e.target.value})}
                                className="w-full bg-zinc-950 border border-zinc-700 rounded-xl pl-10 pr-4 py-3 text-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition" 
                                placeholder={isEditing ? "Deixe em branco para manter a atual" : "Crie uma senha forte"}
                               />
                               <Lock size={16} className="absolute left-3 top-3.5 text-zinc-500" />
                           </div>
                           {isEditing && (
                               <p className="text-[10px] text-amber-500 mt-2 ml-1">
                                   * Preencha apenas se desejar alterar a senha atual do administrador.
                               </p>
                           )}
                       </div>
                       
                       <div className="md:col-span-6 flex items-end gap-3 md:col-start-7">
                           <button 
                            type="button" 
                            onClick={() => setShowForm(false)}
                            className="flex-1 px-4 py-3 bg-zinc-800 hover:bg-zinc-700 rounded-xl text-zinc-300 transition font-medium border border-zinc-700"
                           >
                               Cancelar
                           </button>
                           <button 
                            type="submit" 
                            disabled={isSubmitting}
                            className="flex-1 px-4 py-3 bg-blue-600 hover:bg-blue-500 rounded-xl text-white transition disabled:opacity-50 font-bold shadow-lg flex items-center justify-center gap-2"
                           >
                               {isSubmitting ? <Loader2 className="animate-spin" /> : <Save size={18} />}
                               {isEditing ? 'Salvar Alterações' : 'Criar Entidade'}
                           </button>
                       </div>
                   </form>
               </div>
           )}

           {/* List */}
           {isLoading ? (
               <div className="p-20 text-center text-zinc-500 flex flex-col items-center">
                   <Loader2 className="w-10 h-10 animate-spin mb-4 text-emerald-500" />
                   <p className="text-lg">Sincronizando dados...</p>
               </div>
           ) : (
               <div className="overflow-x-auto">
                   <table className="w-full text-left border-collapse">
                       <thead className="bg-zinc-950 text-zinc-400 uppercase text-xs font-bold tracking-wider">
                           <tr>
                               <th className="px-6 py-5 border-b border-zinc-800">Secretaria</th>
                               <th className="px-6 py-5 border-b border-zinc-800">Status</th>
                               <th className="px-6 py-5 border-b border-zinc-800">Acesso (Admin)</th>
                               <th className="px-6 py-5 border-b border-zinc-800 text-right">Controle</th>
                           </tr>
                       </thead>
                       <tbody className="divide-y divide-zinc-800">
                           {secretariats.length > 0 ? secretariats.map(sec => (
                               <tr key={sec.id} className={`transition group ${sec.active ? 'hover:bg-zinc-800/50' : 'bg-red-950/10 hover:bg-red-950/20'}`}>
                                   <td className="px-6 py-4">
                                       <div className="flex items-center gap-3">
                                            {sec.logoUrl ? (
                                                <img src={sec.logoUrl} alt="" className={`w-10 h-10 rounded-full object-cover border ${sec.active ? 'border-zinc-700 bg-zinc-800' : 'border-red-900 bg-red-950 grayscale'}`} />
                                            ) : (
                                                <div className="w-10 h-10 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-zinc-500">
                                                    <Building2 size={18} />
                                                </div>
                                            )}
                                            <div>
                                                <span className={`font-bold block ${sec.active ? 'text-white' : 'text-zinc-500 line-through decoration-red-500'}`}>{sec.name}</span>
                                                <span className="text-xs text-zinc-500 font-mono">{sec.city} - {sec.state}</span>
                                            </div>
                                       </div>
                                   </td>
                                   <td className="px-6 py-4">
                                       <span className={`px-3 py-1 rounded-full text-xs font-bold border ${sec.active ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-red-500/10 text-red-500 border-red-500/20'}`}>
                                           {sec.active ? 'ATIVA' : 'INATIVA'}
                                       </span>
                                   </td>
                                   <td className="px-6 py-4">
                                       {sec.adminEmail ? (
                                           <div className="flex items-center gap-2 text-zinc-400 text-xs">
                                               <KeyRound size={12} className={sec.active ? "text-emerald-500" : "text-zinc-600"} /> 
                                               {sec.adminEmail}
                                           </div>
                                       ) : (
                                           <div className="flex items-center gap-2 text-amber-500 bg-amber-500/10 px-3 py-1 rounded-full w-fit text-xs font-medium border border-amber-500/20">
                                               <AlertTriangle size={12} /> Pendente
                                           </div>
                                       )}
                                   </td>
                                   <td className="px-6 py-4 text-right">
                                       <div className="flex justify-end gap-2">
                                           <button 
                                            onClick={() => handleOpenEdit(sec)}
                                            className="p-2 bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 rounded-lg transition border border-blue-500/20"
                                            title="Editar Dados, Email e Senha"
                                           >
                                               <Pencil size={16} />
                                           </button>
                                           <button 
                                            onClick={() => handleToggleStatus(sec.id, sec.name, sec.active)}
                                            className={`p-2 rounded-lg transition border flex items-center gap-2 ${sec.active 
                                                ? 'bg-zinc-800 text-zinc-400 hover:text-red-400 hover:border-red-500/30' 
                                                : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/20'}`}
                                            title={sec.active ? "Desativar (Ocultar e Bloquear)" : "Ativar (Liberar Acesso)"}
                                           >
                                               {sec.active ? <ToggleRight size={20} /> : <ToggleLeft size={20} />}
                                           </button>
                                       </div>
                                   </td>
                               </tr>
                           )) : (
                               <tr>
                                   <td colSpan={4} className="p-10 text-center text-zinc-500">
                                       Nenhuma secretaria encontrada. Clique em "Adicionar Nova Entidade" para começar.
                                   </td>
                               </tr>
                           )}
                       </tbody>
                   </table>
               </div>
           )}
       </div>
    </div>
  );
};

export default SuperAdminDashboard;