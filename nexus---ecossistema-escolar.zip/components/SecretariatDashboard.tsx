import React, { useState, useEffect } from 'react';
import { User, School } from '../types';
import { getSchoolsBySecretariat, toggleSchoolStatus, saveSchool, getFullSchoolAudit } from '../services/dataService';
import { School as SchoolIcon, Plus, BarChart2, CheckCircle, XCircle, FileText, Download, Loader2, Pencil, Search, ShieldCheck, Key, Printer, Eye, MapPin, Phone, Mail, BookOpen, Layers, Users } from 'lucide-react';

interface SecretariatDashboardProps {
  user: User;
  showToast: (title: string, msg: string, type: 'success' | 'error' | 'info') => void;
}

interface SchoolFormData {
    name: string;
    inep: string;
    password: string;
    address: string;
    phone: string;
    email: string;
    locationZone: 'Urbana' | 'Rural' | '';
    stages: string[];
    modalities: string[];
    managerName: string;
    viceManagerName: string;
    coordinatorName: string;
}

const SecretariatDashboard: React.FC<SecretariatDashboardProps> = ({ user, showToast }) => {
  const [activeTab, setActiveTab] = useState<'SCHOOLS' | 'AUDIT'>('SCHOOLS');
  const [schools, setSchools] = useState<School[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // States para Formulário de Escola
  const [showSchoolForm, setShowSchoolForm] = useState(false);
  const [editingSchool, setEditingSchool] = useState<School | null>(null);
  const [formData, setFormData] = useState<SchoolFormData>({ 
      name: '', inep: '', password: '', 
      address: '', phone: '', email: '',
      locationZone: '', stages: [], modalities: [],
      managerName: '', viceManagerName: '', coordinatorName: ''
  });
  const [isSaving, setIsSaving] = useState(false);

  // States para Auditoria
  const [auditSearch, setAuditSearch] = useState('');
  const [selectedAuditSchool, setSelectedAuditSchool] = useState<any | null>(null);
  const [isLoadingAudit, setIsLoadingAudit] = useState(false);

  // Opções para Selects/Checkboxes
  const STAGES_OPTIONS = ['Ensino Fundamental Anos Iniciais', 'Ensino Fundamental Anos Finais'];
  const MODALITIES_OPTIONS = ['Ensino Regular', 'EJA'];

  // Carregar escolas
  const loadSchools = async () => {
    setIsLoading(true);
    const data = await getSchoolsBySecretariat(user.secretariatId);
    setSchools(data);
    setIsLoading(false);
  };

  useEffect(() => {
    loadSchools();
  }, [user.secretariatId]);

  // --- GESTÃO DE ESCOLAS ---

  const handleToggleStatus = async (schoolId: string, currentStatus: boolean) => {
    const originalSchools = [...schools];
    setSchools(prev => prev.map(s => s.id === schoolId ? { ...s, active: !currentStatus } : s));
    const success = await toggleSchoolStatus(schoolId, currentStatus);
    if (success) {
        showToast('Status Atualizado', 'O status da escola foi alterado.', 'success');
    } else {
        setSchools(originalSchools);
        showToast('Erro', 'Não foi possível alterar o status.', 'error');
    }
  };

  const handleOpenForm = (school?: School) => {
      if (school) {
          setEditingSchool(school);
          setFormData({ 
              name: school.name, 
              inep: school.inep, 
              password: school.password || '',
              address: school.address || '',
              phone: school.phone || '',
              email: school.email || '',
              locationZone: school.locationZone || '',
              stages: school.stages || [],
              modalities: school.modalities || [],
              managerName: school.managerName || '',
              viceManagerName: school.viceManagerName || '',
              coordinatorName: school.coordinatorName || ''
          });
      } else {
          setEditingSchool(null);
          setFormData({ 
              name: '', inep: '', password: '', 
              address: '', phone: '', email: '',
              locationZone: '', stages: [], modalities: [],
              managerName: '', viceManagerName: '', coordinatorName: ''
          });
      }
      setShowSchoolForm(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const generatePassword = () => {
      const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$";
      let pass = "";
      for (let i = 0; i < 8; i++) {
          pass += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      setFormData(prev => ({ ...prev, password: pass }));
  };

  const toggleArrayItem = (field: 'stages' | 'modalities', value: string) => {
      setFormData(prev => {
          const array = prev[field];
          if (array.includes(value)) {
              return { ...prev, [field]: array.filter(item => item !== value) };
          } else {
              return { ...prev, [field]: [...array, value] };
          }
      });
  };

  const handleSaveSchool = async (e: React.FormEvent) => {
      e.preventDefault();
      
      if (!formData.name || !formData.inep || !formData.email || !formData.locationZone) {
          showToast('Campos Obrigatórios', 'Preencha Nome, INEP, E-mail e Localização.', 'info');
          return;
      }

      setIsSaving(true);
      
      const newId = editingSchool ? editingSchool.id : `sch-${Date.now()}`;
      const schoolData: School = {
          id: newId,
          secretariatId: user.secretariatId,
          name: formData.name,
          inep: formData.inep,
          password: formData.password,
          active: editingSchool ? editingSchool.active : true,
          // Novos campos
          address: formData.address,
          phone: formData.phone,
          email: formData.email,
          locationZone: formData.locationZone as 'Urbana' | 'Rural',
          stages: formData.stages,
          modalities: formData.modalities,
          managerName: formData.managerName,
          viceManagerName: formData.viceManagerName,
          coordinatorName: formData.coordinatorName
      };

      const result = await saveSchool(schoolData);
      
      if (result.success) {
          showToast('Sucesso', `Escola ${editingSchool ? 'atualizada' : 'cadastrada'} com sucesso.`, 'success');
          setShowSchoolForm(false);
          loadSchools();
      } else {
          showToast('Erro', result.message || 'Erro ao salvar escola.', 'error');
      }
      setIsSaving(false);
  };

  // --- AUDITORIA ---

  const handleAuditSearch = async (schoolId: string) => {
      setIsLoadingAudit(true);
      const data = await getFullSchoolAudit(schoolId);
      if (data) {
          setSelectedAuditSchool(data);
      } else {
          showToast('Erro', 'Não foi possível recuperar os dados da escola.', 'error');
      }
      setIsLoadingAudit(false);
  };

  const filteredSchoolsForAudit = schools.filter(s => 
      s.name.toLowerCase().includes(auditSearch.toLowerCase()) || 
      s.inep.includes(auditSearch)
  );

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card p-6 rounded-2xl border-l-4 border-blue-500">
            <h3 className="text-zinc-500 dark:text-zinc-400 text-sm font-medium">Escolas na Rede</h3>
            <p className="text-4xl font-bold text-zinc-800 dark:text-white mt-2">
                {isLoading ? '...' : schools.length}
            </p>
        </div>
        <div className="glass-card p-6 rounded-2xl border-l-4 border-emerald-500">
            <h3 className="text-zinc-500 dark:text-zinc-400 text-sm font-medium">Escolas Ativas</h3>
            <p className="text-4xl font-bold text-zinc-800 dark:text-white mt-2">
                {isLoading ? '...' : schools.filter(s => s.active).length}
            </p>
        </div>
        <div className="glass-card p-6 rounded-2xl border-l-4 border-purple-500">
            <h3 className="text-zinc-500 dark:text-zinc-400 text-sm font-medium">Total de Alunos (Estimado)</h3>
            <p className="text-4xl font-bold text-zinc-800 dark:text-white mt-2">12.450</p>
        </div>
      </div>

      {/* Toolbar */}
      <div className="glass-card p-4 rounded-2xl flex flex-col sm:flex-row justify-between items-center gap-4">
        <h2 className="text-xl font-bold text-zinc-800 dark:text-white px-2">Gestão da Rede</h2>
        <div className="flex bg-zinc-100/50 dark:bg-zinc-800/50 p-1 rounded-xl backdrop-blur-sm">
            <button 
                onClick={() => setActiveTab('SCHOOLS')}
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-all flex items-center gap-2 ${activeTab === 'SCHOOLS' ? 'bg-white dark:bg-zinc-700 shadow text-blue-700 dark:text-blue-300' : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'}`}
            >
                <SchoolIcon className="w-4 h-4" /> Escolas
            </button>
            <button 
                onClick={() => setActiveTab('AUDIT')}
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-all flex items-center gap-2 ${activeTab === 'AUDIT' ? 'bg-white dark:bg-zinc-700 shadow text-blue-700 dark:text-blue-300' : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'}`}
            >
                <ShieldCheck className="w-4 h-4" /> Auditoria
            </button>
        </div>
      </div>

      {/* --- TAB: ESCOLAS --- */}
      {activeTab === 'SCHOOLS' && (
        <div className="glass-card rounded-2xl border border-white/20 dark:border-zinc-700 overflow-hidden animate-fade-in-up">
             {showSchoolForm ? (
                 <div className="p-8 bg-zinc-50 dark:bg-zinc-800/30">
                     <div className="flex justify-between items-center mb-6">
                        <h3 className="text-lg font-bold text-zinc-800 dark:text-white flex items-center gap-2">
                            {editingSchool ? <Pencil size={18} /> : <Plus size={18} />}
                            {editingSchool ? 'Editar Escola' : 'Nova Escola'}
                        </h3>
                        <button onClick={() => setShowSchoolForm(false)} className="text-zinc-500 hover:text-red-500"><XCircle size={24} /></button>
                     </div>
                     <form onSubmit={handleSaveSchool} className="space-y-8 max-w-4xl mx-auto">
                        
                        {/* Seção 1: Identificação e Acesso */}
                        <section>
                            <h4 className="text-xs font-bold uppercase text-blue-500 mb-4 border-b border-zinc-200 dark:border-zinc-700 pb-2 flex items-center gap-2">
                                <Key size={14} /> Identificação e Acesso
                            </h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="md:col-span-2">
                                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-2">Nome da Escola</label>
                                    <input 
                                        required
                                        value={formData.name}
                                        onChange={e => setFormData({...formData, name: e.target.value})}
                                        className="w-full px-4 py-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none dark:text-white" 
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-2">Código INEP (Login)</label>
                                    <input 
                                        required
                                        value={formData.inep}
                                        onChange={e => setFormData({...formData, inep: e.target.value})}
                                        className="w-full px-4 py-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none dark:text-white font-mono" 
                                        placeholder="00000000"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-2">Senha de Acesso (SaaS)</label>
                                    <div className="flex gap-2">
                                        <input 
                                            required={!editingSchool}
                                            type="text"
                                            value={formData.password}
                                            onChange={e => setFormData({...formData, password: e.target.value})}
                                            className="w-full px-4 py-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none dark:text-white font-mono" 
                                            placeholder="Gere ou digite..."
                                        />
                                        <button 
                                            type="button" 
                                            onClick={generatePassword}
                                            className="px-4 py-2 bg-zinc-200 dark:bg-zinc-700 rounded-xl text-zinc-600 dark:text-zinc-300 hover:bg-zinc-300 dark:hover:bg-zinc-600"
                                            title="Gerar Senha Segura"
                                        >
                                            <Key size={18} />
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </section>

                        {/* Seção 2: Equipe Gestora (NOVO) */}
                        <section>
                            <h4 className="text-xs font-bold uppercase text-orange-500 mb-4 border-b border-zinc-200 dark:border-zinc-700 pb-2 flex items-center gap-2">
                                <Users size={14} /> Equipe Gestora
                            </h4>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div>
                                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-2">Nome do Gestor(a)</label>
                                    <input 
                                        value={formData.managerName}
                                        onChange={e => setFormData({...formData, managerName: e.target.value})}
                                        className="w-full px-4 py-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none dark:text-white" 
                                        placeholder="Diretor Geral"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-2">Nome do Vice-Gestor(a)</label>
                                    <input 
                                        value={formData.viceManagerName}
                                        onChange={e => setFormData({...formData, viceManagerName: e.target.value})}
                                        className="w-full px-4 py-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none dark:text-white" 
                                        placeholder="Vice Diretor"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-2">Nome do Coordenador(a)</label>
                                    <input 
                                        value={formData.coordinatorName}
                                        onChange={e => setFormData({...formData, coordinatorName: e.target.value})}
                                        className="w-full px-4 py-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none dark:text-white" 
                                        placeholder="Coordenação Pedagógica"
                                    />
                                </div>
                            </div>
                        </section>

                        {/* Seção 3: Contato e Localização */}
                        <section>
                            <h4 className="text-xs font-bold uppercase text-emerald-500 mb-4 border-b border-zinc-200 dark:border-zinc-700 pb-2 flex items-center gap-2">
                                <MapPin size={14} /> Contato e Localização
                            </h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="md:col-span-2">
                                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-2">Endereço Completo</label>
                                    <input 
                                        value={formData.address}
                                        onChange={e => setFormData({...formData, address: e.target.value})}
                                        className="w-full px-4 py-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none dark:text-white" 
                                        placeholder="Rua, Número, Bairro, CEP"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-2">Telefone</label>
                                    <div className="relative">
                                        <input 
                                            value={formData.phone}
                                            onChange={e => setFormData({...formData, phone: e.target.value})}
                                            className="w-full pl-10 pr-4 py-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none dark:text-white" 
                                            placeholder="(00) 0000-0000"
                                        />
                                        <Phone size={18} className="absolute left-3 top-3.5 text-zinc-400" />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-2">E-mail Institucional (Acesso)</label>
                                    <div className="relative">
                                        <input 
                                            required
                                            type="email"
                                            value={formData.email}
                                            onChange={e => setFormData({...formData, email: e.target.value})}
                                            className="w-full pl-10 pr-4 py-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none dark:text-white" 
                                            placeholder="escola@educacao.gov.br"
                                        />
                                        <Mail size={18} className="absolute left-3 top-3.5 text-zinc-400" />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-2">Localização (Zona)</label>
                                    <select
                                        required
                                        value={formData.locationZone}
                                        onChange={e => setFormData({...formData, locationZone: e.target.value as any})}
                                        className="w-full px-4 py-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none dark:text-white"
                                    >
                                        <option value="">Selecione...</option>
                                        <option value="Urbana">Urbana</option>
                                        <option value="Rural">Rural</option>
                                    </select>
                                </div>
                            </div>
                        </section>

                        {/* Seção 4: Caracterização Pedagógica */}
                        <section>
                            <h4 className="text-xs font-bold uppercase text-purple-500 mb-4 border-b border-zinc-200 dark:border-zinc-700 pb-2 flex items-center gap-2">
                                <BookOpen size={14} /> Caracterização Pedagógica
                            </h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                <div>
                                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-3">Etapas de Ensino</label>
                                    <div className="space-y-3 bg-white dark:bg-zinc-900 p-4 rounded-xl border border-zinc-200 dark:border-zinc-700">
                                        {STAGES_OPTIONS.map(stage => (
                                            <label key={stage} className="flex items-center gap-3 cursor-pointer">
                                                <input 
                                                    type="checkbox" 
                                                    checked={formData.stages.includes(stage)}
                                                    onChange={() => toggleArrayItem('stages', stage)}
                                                    className="w-5 h-5 rounded text-purple-600 focus:ring-purple-500 border-zinc-300"
                                                />
                                                <span className="text-sm text-zinc-700 dark:text-zinc-300">{stage}</span>
                                            </label>
                                        ))}
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-3">Modalidades</label>
                                    <div className="space-y-3 bg-white dark:bg-zinc-900 p-4 rounded-xl border border-zinc-200 dark:border-zinc-700">
                                        {MODALITIES_OPTIONS.map(modality => (
                                            <label key={modality} className="flex items-center gap-3 cursor-pointer">
                                                <input 
                                                    type="checkbox" 
                                                    checked={formData.modalities.includes(modality)}
                                                    onChange={() => toggleArrayItem('modalities', modality)}
                                                    className="w-5 h-5 rounded text-purple-600 focus:ring-purple-500 border-zinc-300"
                                                />
                                                <span className="text-sm text-zinc-700 dark:text-zinc-300">{modality}</span>
                                            </label>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </section>

                        <div className="flex justify-end pt-6 border-t border-zinc-200 dark:border-zinc-700">
                            <button 
                                type="submit" 
                                disabled={isSaving}
                                className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl flex items-center gap-2 shadow-lg disabled:opacity-50 transition transform hover:-translate-y-0.5"
                            >
                                {isSaving ? <Loader2 className="animate-spin" /> : <CheckCircle size={18} />}
                                Salvar Cadastro Escolar
                            </button>
                        </div>
                     </form>
                 </div>
             ) : (
                <>
                    <div className="p-6 border-b border-zinc-200/50 dark:border-zinc-700/50 flex justify-between items-center bg-white/30 dark:bg-zinc-800/30">
                        <h3 className="font-bold text-zinc-800 dark:text-white">Unidades Escolares</h3>
                        <button 
                            onClick={() => handleOpenForm()}
                            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition"
                        >
                            <Plus size={16} /> Nova Escola
                        </button>
                    </div>
                    
                    {isLoading ? (
                        <div className="p-12 text-center flex flex-col items-center justify-center text-zinc-500">
                            <Loader2 className="w-8 h-8 animate-spin mb-2 text-blue-500" />
                            <p>Carregando escolas do ecossistema...</p>
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left">
                                <thead className="bg-zinc-50/50 dark:bg-zinc-800/50 text-zinc-500 dark:text-zinc-400 uppercase text-xs font-bold border-b border-zinc-200 dark:border-zinc-700">
                                    <tr>
                                        <th className="px-6 py-4">INEP</th>
                                        <th className="px-6 py-4">Escola / Contato</th>
                                        <th className="px-6 py-4">Equipe Gestora</th>
                                        <th className="px-6 py-4 text-center">Status</th>
                                        <th className="px-6 py-4 text-center">Ações</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-zinc-100 dark:divide-zinc-700/50">
                                    {schools.length > 0 ? schools.map(school => (
                                        <tr key={school.id} className="hover:bg-zinc-50/50 dark:hover:bg-zinc-800/50 transition">
                                            <td className="px-6 py-4 font-mono text-zinc-500 dark:text-zinc-400">{school.inep}</td>
                                            <td className="px-6 py-4">
                                                <p className="font-medium text-zinc-900 dark:text-zinc-200">{school.name}</p>
                                                <p className="text-xs text-zinc-500 mt-1 flex items-center gap-1"><Mail size={10}/> {school.email || 'Sem email'}</p>
                                                <p className="text-xs text-zinc-500 flex items-center gap-1"><Phone size={10}/> {school.phone || 'Sem telefone'}</p>
                                            </td>
                                            <td className="px-6 py-4">
                                                <div className="text-xs space-y-1">
                                                    {school.managerName && <p className="text-zinc-700 dark:text-zinc-300"><strong>Gestor:</strong> {school.managerName}</p>}
                                                    {school.coordinatorName && <p className="text-zinc-500 dark:text-zinc-400"><strong>Coord:</strong> {school.coordinatorName}</p>}
                                                    {!school.managerName && !school.coordinatorName && <span className="text-zinc-400 italic">Não informado</span>}
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${school.active ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'}`}>
                                                    {school.active ? 'Ativa' : 'Inativa'}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                <div className="flex justify-center gap-2">
                                                    <button 
                                                        onClick={() => handleOpenForm(school)}
                                                        className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 dark:bg-blue-900/30 dark:text-blue-400 dark:hover:bg-blue-900/50 transition"
                                                        title="Editar Informações"
                                                    >
                                                        <Pencil size={16} />
                                                    </button>
                                                    <button 
                                                        onClick={() => handleToggleStatus(school.id, school.active)}
                                                        className={`p-2 rounded-lg transition border ${school.active 
                                                            ? 'text-zinc-400 hover:text-red-500 border-transparent hover:bg-red-50 dark:hover:bg-red-900/20' 
                                                            : 'text-emerald-500 border-emerald-200 bg-emerald-50 hover:bg-emerald-100'}`}
                                                        title={school.active ? "Desativar" : "Ativar"}
                                                    >
                                                        {school.active ? <XCircle size={16} /> : <CheckCircle size={16} />}
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    )) : (
                                        <tr>
                                            <td colSpan={5} className="px-6 py-8 text-center text-zinc-500 dark:text-zinc-400">
                                                Nenhuma escola cadastrada nesta secretaria.
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    )}
                </>
             )}
        </div>
      )}

      {/* --- TAB: AUDITORIA --- */}
      {activeTab === 'AUDIT' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in-up">
              {/* Sidebar de Busca */}
              <div className="lg:col-span-4 glass-card rounded-2xl p-6 h-fit sticky top-6">
                  <h3 className="font-bold text-zinc-800 dark:text-white mb-4 flex items-center gap-2">
                      <Search size={18} /> Buscar Escola
                  </h3>
                  <input 
                      type="text" 
                      placeholder="Nome ou INEP..." 
                      className="w-full px-4 py-2 bg-zinc-100 dark:bg-zinc-800 border-none rounded-xl mb-4 focus:ring-2 focus:ring-blue-500 outline-none dark:text-white"
                      value={auditSearch}
                      onChange={(e) => setAuditSearch(e.target.value)}
                  />
                  <div className="space-y-2 max-h-96 overflow-y-auto pr-2">
                      {filteredSchoolsForAudit.map(school => (
                          <button 
                              key={school.id}
                              onClick={() => handleAuditSearch(school.id)}
                              className={`w-full text-left p-3 rounded-xl transition text-sm flex justify-between items-center ${selectedAuditSchool?.school.id === school.id ? 'bg-blue-600 text-white shadow-lg' : 'bg-white dark:bg-zinc-800/50 hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-600 dark:text-zinc-300'}`}
                          >
                              <span className="truncate font-medium">{school.name}</span>
                              <ShieldCheck size={14} className={selectedAuditSchool?.school.id === school.id ? 'text-white' : 'text-zinc-400'} />
                          </button>
                      ))}
                      {filteredSchoolsForAudit.length === 0 && (
                          <p className="text-center text-zinc-400 text-sm py-4">Nenhuma escola encontrada.</p>
                      )}
                  </div>
              </div>

              {/* Área de Visualização do Relatório */}
              <div className="lg:col-span-8">
                  {isLoadingAudit ? (
                      <div className="glass-card rounded-2xl p-20 flex flex-col items-center justify-center text-zinc-500">
                          <Loader2 className="w-10 h-10 animate-spin text-blue-600 mb-4" />
                          <p>Gerando dossiê da escola...</p>
                      </div>
                  ) : selectedAuditSchool ? (
                      <div className="glass-card rounded-2xl overflow-hidden print:shadow-none print:border-none">
                          {/* Cabeçalho do Relatório */}
                          <div className="bg-zinc-50 dark:bg-zinc-800/80 p-8 border-b border-zinc-200 dark:border-zinc-700">
                              <div className="flex justify-between items-start">
                                  <div>
                                      <h2 className="text-2xl font-bold text-zinc-900 dark:text-white">{selectedAuditSchool.school.name}</h2>
                                      <p className="text-zinc-500 dark:text-zinc-400 mt-1">INEP: {selectedAuditSchool.school.inep}</p>
                                  </div>
                                  <button 
                                      onClick={() => window.print()} 
                                      className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition print:hidden shadow-lg"
                                  >
                                      <Printer size={16} /> Imprimir / PDF
                                  </button>
                              </div>
                              <div className="grid grid-cols-3 gap-4 mt-6">
                                  <div className="bg-white dark:bg-zinc-900 p-4 rounded-xl border border-zinc-100 dark:border-zinc-700 text-center">
                                      <p className="text-xs text-zinc-500 uppercase font-bold">Alunos</p>
                                      <p className="text-2xl font-bold text-zinc-800 dark:text-white">{selectedAuditSchool.students.length}</p>
                                  </div>
                                  <div className="bg-white dark:bg-zinc-900 p-4 rounded-xl border border-zinc-100 dark:border-zinc-700 text-center">
                                      <p className="text-xs text-zinc-500 uppercase font-bold">Professores/Staff</p>
                                      <p className="text-2xl font-bold text-zinc-800 dark:text-white">{selectedAuditSchool.staff.length}</p>
                                  </div>
                                  <div className="bg-white dark:bg-zinc-900 p-4 rounded-xl border border-zinc-100 dark:border-zinc-700 text-center">
                                      <p className="text-xs text-zinc-500 uppercase font-bold">Status</p>
                                      <p className={`text-xl font-bold ${selectedAuditSchool.school.active ? 'text-green-600' : 'text-red-600'}`}>
                                          {selectedAuditSchool.school.active ? 'Regular' : 'Irregular'}
                                      </p>
                                  </div>
                              </div>
                          </div>

                          {/* Conteúdo do Relatório */}
                          <div className="p-8 space-y-8">
                               {/* NOVA SEÇÃO DE EQUIPE GESTORA NO RELATÓRIO */}
                              <section>
                                  <h4 className="text-sm font-bold text-zinc-500 uppercase tracking-widest border-b border-zinc-200 dark:border-zinc-700 pb-2 mb-4">Direção e Coordenação</h4>
                                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                      <div className="bg-zinc-50 dark:bg-zinc-900 p-4 rounded-xl">
                                          <p className="text-xs text-zinc-500 uppercase">Gestor(a)</p>
                                          <p className="font-bold text-zinc-800 dark:text-zinc-200">{selectedAuditSchool.school.manager_name || 'Não informado'}</p>
                                      </div>
                                      <div className="bg-zinc-50 dark:bg-zinc-900 p-4 rounded-xl">
                                          <p className="text-xs text-zinc-500 uppercase">Vice-Gestor(a)</p>
                                          <p className="font-bold text-zinc-800 dark:text-zinc-200">{selectedAuditSchool.school.vice_manager_name || 'Não informado'}</p>
                                      </div>
                                      <div className="bg-zinc-50 dark:bg-zinc-900 p-4 rounded-xl">
                                          <p className="text-xs text-zinc-500 uppercase">Coordenação</p>
                                          <p className="font-bold text-zinc-800 dark:text-zinc-200">{selectedAuditSchool.school.coordinator_name || 'Não informado'}</p>
                                      </div>
                                  </div>
                              </section>

                              <section>
                                  <h4 className="text-sm font-bold text-zinc-500 uppercase tracking-widest border-b border-zinc-200 dark:border-zinc-700 pb-2 mb-4">Corpo Docente (Sistema)</h4>
                                  <table className="w-full text-sm text-left">
                                      <thead className="bg-zinc-50 dark:bg-zinc-900 text-zinc-500 uppercase text-xs">
                                          <tr>
                                              <th className="px-4 py-2">Nome</th>
                                              <th className="px-4 py-2">Função</th>
                                              <th className="px-4 py-2">Email</th>
                                          </tr>
                                      </thead>
                                      <tbody className="divide-y divide-zinc-100 dark:divide-zinc-700">
                                          {selectedAuditSchool.staff.map((p: User) => (
                                              <tr key={p.id}>
                                                  <td className="px-4 py-2 text-zinc-800 dark:text-zinc-300">{p.name}</td>
                                                  <td className="px-4 py-2 text-zinc-600 dark:text-zinc-400 text-xs font-bold">{p.role}</td>
                                                  <td className="px-4 py-2 text-zinc-500 dark:text-zinc-400">{p.email}</td>
                                              </tr>
                                          ))}
                                          {selectedAuditSchool.staff.length === 0 && <tr><td colSpan={3} className="px-4 py-2 text-center text-zinc-400">Nenhum registro.</td></tr>}
                                      </tbody>
                                  </table>
                              </section>

                              <section>
                                  <h4 className="text-sm font-bold text-zinc-500 uppercase tracking-widest border-b border-zinc-200 dark:border-zinc-700 pb-2 mb-4">Discentes Matriculados</h4>
                                  <table className="w-full text-sm text-left">
                                      <thead className="bg-zinc-50 dark:bg-zinc-900 text-zinc-500 uppercase text-xs">
                                          <tr>
                                              <th className="px-4 py-2">Matrícula</th>
                                              <th className="px-4 py-2">Nome</th>
                                              <th className="px-4 py-2">Turma</th>
                                              <th className="px-4 py-2">Nascimento</th>
                                          </tr>
                                      </thead>
                                      <tbody className="divide-y divide-zinc-100 dark:divide-zinc-700">
                                          {selectedAuditSchool.students.map((s: any) => (
                                              <tr key={s.id}>
                                                  <td className="px-4 py-2 font-mono text-zinc-500 dark:text-zinc-400">{s.matricula}</td>
                                                  <td className="px-4 py-2 text-zinc-800 dark:text-zinc-300">{s.name}</td>
                                                  <td className="px-4 py-2 text-zinc-600 dark:text-zinc-400">{s.class_name}</td>
                                                  <td className="px-4 py-2 text-zinc-500 dark:text-zinc-400">{new Date(s.birth_date).toLocaleDateString('pt-BR')}</td>
                                              </tr>
                                          ))}
                                          {selectedAuditSchool.students.length === 0 && <tr><td colSpan={4} className="px-4 py-2 text-center text-zinc-400">Nenhum aluno matriculado.</td></tr>}
                                      </tbody>
                                  </table>
                              </section>
                              
                              <div className="text-center pt-8 border-t border-zinc-200 dark:border-zinc-700">
                                  <p className="text-xs text-zinc-400">Documento gerado eletronicamente pelo sistema NEXUS em {new Date().toLocaleString('pt-BR')}</p>
                                  <p className="text-xs text-zinc-400">Chave de autenticação: {selectedAuditSchool.school.id.split('-')[1].toUpperCase()}-{Date.now()}</p>
                              </div>
                          </div>
                      </div>
                  ) : (
                      <div className="glass-card rounded-2xl p-12 text-center border-2 border-dashed border-zinc-300 dark:border-zinc-700 flex flex-col items-center justify-center h-full min-h-[400px]">
                          <BarChart2 className="w-16 h-16 text-zinc-300 dark:text-zinc-600 mb-4" />
                          <h3 className="text-xl font-bold text-zinc-700 dark:text-zinc-300">Selecione uma Escola</h3>
                          <p className="text-zinc-500 dark:text-zinc-400 mt-2 max-w-sm">Utilize a barra lateral para buscar e selecionar uma unidade escolar para auditoria completa.</p>
                      </div>
                  )}
              </div>
          </div>
      )}
    </div>
  );
};

export default SecretariatDashboard;