import React, { useEffect, useState } from 'react';
import { User, School } from '../types';
import { getSchoolStats } from '../services/dataService';
import { Users, GraduationCap, UserPlus, Settings, FileText, Download, Loader2 } from 'lucide-react';

interface SchoolManagerDashboardProps {
  user: User;
  school: School;
  showToast: (title: string, msg: string, type: 'success' | 'error' | 'info') => void;
}

const SchoolManagerDashboard: React.FC<SchoolManagerDashboardProps> = ({ user, school, showToast }) => {
  const [stats, setStats] = useState<{ studentCount: number, professors: User[] }>({ studentCount: 0, professors: [] });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
        setIsLoading(true);
        const data = await getSchoolStats(school.id);
        setStats(data);
        setIsLoading(false);
    };
    loadStats();
  }, [school.id]);

  const handleExport = () => {
    showToast('Exportando', 'Gerando relatório da escola em PDF...', 'info');
    setTimeout(() => window.print(), 1000);
  };

  return (
    <div className="space-y-6 animate-fade-in-up">
       {/* School Header Info */}
       <div className="glass-card p-6 rounded-2xl flex flex-col md:flex-row justify-between items-center gap-4 bg-gradient-to-r from-blue-600/10 to-indigo-600/10 dark:from-blue-900/20 dark:to-indigo-900/20 border border-blue-200 dark:border-blue-900">
          <div>
              <h2 className="text-2xl font-bold text-zinc-800 dark:text-white">{school.name}</h2>
              <p className="text-zinc-500 dark:text-zinc-400">INEP: {school.inep} | Gestor: {user.name}</p>
          </div>
          <div className="flex gap-3">
              <button 
                onClick={handleExport}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:text-blue-600 dark:hover:text-blue-400 shadow-sm transition text-sm font-medium"
              >
                  <Download size={16} /> Relatório Geral
              </button>
              <button className="p-2 rounded-lg bg-white dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:text-blue-600 dark:hover:text-blue-400 shadow-sm transition">
                  <Settings size={20} />
              </button>
          </div>
       </div>

       <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Professors Management */}
          <div className="glass-card rounded-2xl overflow-hidden border border-white/20 dark:border-zinc-700 animate-fade-in-up" style={{animationDelay: '0.1s'}}>
              <div className="p-6 border-b border-zinc-200/50 dark:border-zinc-700/50 flex justify-between items-center">
                  <h3 className="font-bold text-zinc-800 dark:text-white flex items-center gap-2">
                      <GraduationCap className="text-blue-500" /> Corpo Docente
                  </h3>
                  <button 
                    onClick={() => showToast('Simulação', 'Modal de cadastro de professor.', 'info')}
                    className="text-xs bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 px-3 py-1.5 rounded-lg font-bold flex items-center gap-1 hover:bg-blue-200 dark:hover:bg-blue-900 transition"
                  >
                      <UserPlus size={14} /> Adicionar
                  </button>
              </div>
              <div className="p-0">
                  {isLoading ? (
                      <div className="p-8 text-center text-zinc-400 flex justify-center">
                          <Loader2 className="animate-spin" />
                      </div>
                  ) : stats.professors.length > 0 ? (
                      <table className="w-full text-sm text-left">
                          <tbody className="divide-y divide-zinc-100 dark:divide-zinc-700/50">
                              {stats.professors.map(prof => (
                                  <tr key={prof.id} className="hover:bg-zinc-50/50 dark:hover:bg-zinc-800/50 transition">
                                      <td className="px-6 py-4">
                                          <p className="font-medium text-zinc-900 dark:text-zinc-200">{prof.name}</p>
                                          <p className="text-xs text-zinc-500 dark:text-zinc-400">{prof.email}</p>
                                      </td>
                                      <td className="px-6 py-4 text-right">
                                          <button className="text-blue-600 dark:text-blue-400 text-xs font-medium hover:underline">Editar Lotação</button>
                                      </td>
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                  ) : (
                      <div className="p-6 text-center text-zinc-500 dark:text-zinc-400 text-sm">Nenhum professor lotado.</div>
                  )}
              </div>
          </div>

          {/* Students Stats */}
          <div className="glass-card rounded-2xl overflow-hidden border border-white/20 dark:border-zinc-700 animate-fade-in-up" style={{animationDelay: '0.2s'}}>
              <div className="p-6 border-b border-zinc-200/50 dark:border-zinc-700/50 flex justify-between items-center">
                  <h3 className="font-bold text-zinc-800 dark:text-white flex items-center gap-2">
                      <Users className="text-emerald-500" /> Alunos Matriculados
                  </h3>
                  <span className="text-xs bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300 px-3 py-1.5 rounded-full font-bold">
                      {isLoading ? '...' : `Total: ${stats.studentCount}`}
                  </span>
              </div>
              <div className="p-6">
                 <div className="grid grid-cols-2 gap-4">
                     <div className="bg-zinc-50 dark:bg-zinc-800/50 p-4 rounded-xl text-center">
                         <p className="text-xs text-zinc-500 dark:text-zinc-400 uppercase font-bold">Turmas Ativas</p>
                         <p className="text-2xl font-bold text-zinc-800 dark:text-white mt-1">12</p>
                     </div>
                     <div className="bg-zinc-50 dark:bg-zinc-800/50 p-4 rounded-xl text-center">
                         <p className="text-xs text-zinc-500 dark:text-zinc-400 uppercase font-bold">Transferências</p>
                         <p className="text-2xl font-bold text-zinc-800 dark:text-white mt-1">3</p>
                     </div>
                 </div>
                 <button className="w-full mt-4 py-3 border border-zinc-200 dark:border-zinc-600 rounded-xl text-zinc-600 dark:text-zinc-300 font-medium hover:bg-zinc-50 dark:hover:bg-zinc-800 transition flex items-center justify-center gap-2">
                     <FileText size={16} /> Ver Lista Completa de Alunos
                 </button>
              </div>
          </div>
       </div>
    </div>
  );
};

export default SchoolManagerDashboard;