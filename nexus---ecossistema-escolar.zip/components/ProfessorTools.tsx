import React, { useState, useEffect } from 'react';
import { User, School, Student } from '../types';
import { SUBJECTS, BNCC_SKILLS } from '../constants';
import { getStudentsByClass } from '../services/dataService';
import { Save, Calendar, BookOpen, GraduationCap, ExternalLink, FileText, Loader2 } from 'lucide-react';

interface ProfessorToolsProps {
  user: User;
  school: School;
  showToast: (title: string, msg: string, type: 'success' | 'error' | 'info') => void;
}

type Tab = 'DIARY' | 'GRADES' | 'ATTENDANCE';

const ProfessorTools: React.FC<ProfessorToolsProps> = ({ user, school, showToast }) => {
  const [activeTab, setActiveTab] = useState<Tab>('DIARY');
  const [selectedClass, setSelectedClass] = useState('5º Ano A');
  const [selectedSubject, setSelectedSubject] = useState(SUBJECTS[0].id);
  
  // State para dados reais do banco
  const [students, setStudents] = useState<Student[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Busca alunos do Supabase quando a turma ou escola muda
  useEffect(() => {
    const fetchStudents = async () => {
        setIsLoading(true);
        const data = await getStudentsByClass(school.id, selectedClass);
        setStudents(data);
        setIsLoading(false);
    };

    fetchStudents();
  }, [school.id, selectedClass]);

  const handlePrint = () => {
    showToast('Gerando PDF', 'Preparando relatório para impressão...', 'info');
    setTimeout(() => window.print(), 1000);
  };

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Context Bar */}
      <div className="glass-card p-4 rounded-2xl flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="flex gap-4">
          <select 
            className="bg-white/50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-600 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none dark:text-white shadow-sm"
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
          >
            <option>5º Ano A</option>
            <option>5º Ano B</option>
            <option>4º Ano C</option>
            <option>9º Ano B</option>
          </select>
          <select 
            className="bg-white/50 dark:bg-zinc-800/50 border border-zinc-200 dark:border-zinc-600 rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none dark:text-white shadow-sm"
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
          >
            {SUBJECTS.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>
        
        <div className="flex bg-zinc-100/50 dark:bg-zinc-800/50 p-1 rounded-xl backdrop-blur-sm">
           <button 
             onClick={() => setActiveTab('DIARY')}
             className={`px-4 py-2 text-sm font-medium rounded-lg transition-all flex items-center gap-2 ${activeTab === 'DIARY' ? 'bg-white dark:bg-zinc-700 shadow text-blue-700 dark:text-blue-300' : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'}`}
           >
             <BookOpen className="w-4 h-4" /> Diário
           </button>
           <button 
             onClick={() => setActiveTab('ATTENDANCE')}
             className={`px-4 py-2 text-sm font-medium rounded-lg transition-all flex items-center gap-2 ${activeTab === 'ATTENDANCE' ? 'bg-white dark:bg-zinc-700 shadow text-blue-700 dark:text-blue-300' : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'}`}
           >
             <Calendar className="w-4 h-4" /> Frequência
           </button>
           <button 
             onClick={() => setActiveTab('GRADES')}
             className={`px-4 py-2 text-sm font-medium rounded-lg transition-all flex items-center gap-2 ${activeTab === 'GRADES' ? 'bg-white dark:bg-zinc-700 shadow text-blue-700 dark:text-blue-300' : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'}`}
           >
             <GraduationCap className="w-4 h-4" /> Avaliação
           </button>
        </div>
      </div>

      {/* DIARY MODULE */}
      {activeTab === 'DIARY' && (
        <div className="glass-card rounded-2xl border border-white/20 dark:border-zinc-700 animate-fade-in-up">
           <div className="p-6 border-b border-zinc-200/50 dark:border-zinc-700/50 flex justify-between items-center">
             <div className="flex items-center gap-3">
                <h2 className="text-lg font-bold text-zinc-800 dark:text-white">Registro de Aula (BNCC)</h2>
                <a 
                    href="https://www.gov.br/mec/pt-br/escola-em-tempo-integral/BNCC_EI_EF_110518_versaofinal.pdf" 
                    target="_blank" 
                    rel="noreferrer"
                    className="text-xs flex items-center gap-1 text-blue-600 hover:underline bg-blue-50 dark:bg-blue-900/30 px-2 py-1 rounded"
                >
                    <ExternalLink size={10} /> Consultar BNCC
                </a>
             </div>
             <div className="flex items-center gap-2">
                 <button onClick={handlePrint} className="p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg text-zinc-500" title="Imprimir Diário">
                    <FileText size={18} />
                 </button>
                 <span className="text-sm text-zinc-500 dark:text-zinc-400 bg-zinc-100 dark:bg-zinc-800 px-3 py-1 rounded-full">{new Date().toLocaleDateString('pt-BR')}</span>
             </div>
           </div>
           <div className="p-6 space-y-6">
              <div>
                <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-2">Conteúdo Programático</label>
                <input type="text" className="w-full bg-white/50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-600 rounded-xl px-4 py-3 text-sm focus:ring-blue-500 focus:border-blue-500 dark:text-white outline-none" placeholder="Ex: Introdução às Frações" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <div>
                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-2">Metodologia & Recursos</label>
                    <textarea className="w-full h-40 bg-white/50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-600 rounded-xl px-4 py-3 text-sm focus:ring-blue-500 focus:border-blue-500 dark:text-white outline-none resize-none" placeholder="Descreva como a aula será ministrada..." />
                 </div>
                 <div>
                    <label className="block text-sm font-bold text-zinc-600 dark:text-zinc-300 mb-2">Habilidades BNCC</label>
                    <div className="h-40 border border-zinc-200 dark:border-zinc-600 rounded-xl overflow-y-auto p-2 bg-zinc-50/50 dark:bg-zinc-900/50">
                        {BNCC_SKILLS.map((skill) => (
                           <label key={skill.code} className="flex items-start gap-3 mb-2 cursor-pointer hover:bg-white/50 dark:hover:bg-zinc-800/50 p-2 rounded-lg transition">
                             <input type="checkbox" className="mt-1 rounded text-blue-600 focus:ring-blue-500 border-gray-300" />
                             <div className="text-xs">
                               <span className="font-bold text-zinc-700 dark:text-zinc-200">{skill.code}</span>
                               <p className="text-zinc-500 dark:text-zinc-400 leading-snug">{skill.description}</p>
                             </div>
                           </label>
                        ))}
                    </div>
                 </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-zinc-200/50 dark:border-zinc-700/50">
                 <button className="px-6 py-2.5 text-sm font-medium text-zinc-600 dark:text-zinc-300 bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-600 rounded-xl hover:bg-zinc-50 dark:hover:bg-zinc-700 transition">Cancelar</button>
                 <button 
                  onClick={() => showToast('Sucesso', 'Registro de aula salvo com sucesso!', 'success')}
                  className="px-6 py-2.5 text-sm font-medium text-white bg-blue-600 rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-500/30 flex items-center gap-2 transition"
                 >
                   <Save className="w-4 h-4" /> Salvar Diário
                 </button>
              </div>
           </div>
        </div>
      )}

      {/* ATTENDANCE MODULE */}
      {activeTab === 'ATTENDANCE' && (
        <div className="glass-card rounded-2xl border border-white/20 dark:border-zinc-700 overflow-hidden animate-fade-in-up">
          <div className="p-6 border-b border-zinc-200/50 dark:border-zinc-700/50 flex justify-between items-center">
             <h2 className="text-lg font-bold text-zinc-800 dark:text-white">Chamada Diária</h2>
             <div className="text-xs font-bold bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 px-3 py-1.5 rounded-full uppercase tracking-wide">
               Total: {students.length} Alunos
             </div>
           </div>
           
           {isLoading ? (
               <div className="p-12 text-center flex flex-col items-center justify-center text-zinc-400">
                   <Loader2 className="w-8 h-8 animate-spin mb-2" />
                   <p>Carregando lista de alunos...</p>
               </div>
           ) : (
               <div className="overflow-x-auto">
                 <table className="w-full text-sm text-left">
                   <thead className="bg-zinc-50/50 dark:bg-zinc-800/50 text-zinc-500 dark:text-zinc-400 uppercase text-xs font-bold border-b border-zinc-200 dark:border-zinc-700">
                     <tr>
                       <th className="px-6 py-4">Matrícula</th>
                       <th className="px-6 py-4">Nome do Aluno</th>
                       <th className="px-6 py-4 text-center">Presença</th>
                       <th className="px-6 py-4">Justificativa</th>
                     </tr>
                   </thead>
                   <tbody>
                     {students.length > 0 ? students.map((student) => (
                       <tr key={student.id} className="border-b border-zinc-100 dark:border-zinc-700/50 hover:bg-zinc-50/50 dark:hover:bg-zinc-800/50 transition">
                         <td className="px-6 py-4 font-mono text-zinc-500 dark:text-zinc-400">{student.matricula}</td>
                         <td className="px-6 py-4 font-medium text-zinc-900 dark:text-zinc-200">{student.name}</td>
                         <td className="px-6 py-4 text-center">
                            <div className="flex justify-center gap-4">
                               <label className="flex items-center gap-1.5 cursor-pointer">
                                 <input type="radio" name={`att-${student.id}`} defaultChecked className="accent-green-600 w-4 h-4" />
                                 <span className="text-zinc-600 dark:text-zinc-400 font-medium text-xs">P</span>
                               </label>
                               <label className="flex items-center gap-1.5 cursor-pointer">
                                 <input type="radio" name={`att-${student.id}`} className="accent-red-600 w-4 h-4" />
                                 <span className="text-zinc-600 dark:text-zinc-400 font-medium text-xs">F</span>
                               </label>
                            </div>
                         </td>
                         <td className="px-6 py-4">
                            <input type="text" className="w-full text-xs border-b border-zinc-300 dark:border-zinc-600 focus:border-blue-500 outline-none bg-transparent dark:text-zinc-300 placeholder-zinc-400" placeholder="Adicionar nota..." />
                         </td>
                       </tr>
                     )) : (
                         <tr>
                             <td colSpan={4} className="px-6 py-8 text-center text-zinc-500">
                                 Nenhum aluno encontrado nesta turma ({selectedClass}).
                             </td>
                         </tr>
                     )}
                   </tbody>
                 </table>
               </div>
           )}
           
           <div className="p-4 bg-zinc-50/30 dark:bg-zinc-800/30 border-t border-zinc-200 dark:border-zinc-700 flex justify-end gap-2">
             <button onClick={handlePrint} className="px-4 py-2.5 text-zinc-600 dark:text-zinc-400 bg-white dark:bg-zinc-800 rounded-xl text-sm font-medium hover:bg-zinc-50 border border-zinc-200 dark:border-zinc-600 transition">
                Exportar Frequência
             </button>
             <button 
               onClick={() => showToast('Chamada Finalizada', 'Frequência registrada com sucesso!', 'success')}
               className="px-6 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700 shadow-lg shadow-blue-500/30 transition"
               disabled={students.length === 0}
             >
               Finalizar Chamada
             </button>
           </div>
        </div>
      )}

      {/* GRADES MODULE */}
      {activeTab === 'GRADES' && (
        <div className="glass-card rounded-2xl border border-white/20 dark:border-zinc-700 overflow-hidden animate-fade-in-up">
          <div className="p-6 border-b border-zinc-200/50 dark:border-zinc-700/50 flex justify-between items-center">
             <h2 className="text-lg font-bold text-zinc-800 dark:text-white">Lançamento de Notas - 1º Bimestre</h2>
           </div>
           
           {isLoading ? (
               <div className="p-12 text-center flex flex-col items-center justify-center text-zinc-400">
                   <Loader2 className="w-8 h-8 animate-spin mb-2" />
                   <p>Carregando pauta de avaliação...</p>
               </div>
           ) : (
               <div className="overflow-x-auto">
                 <table className="w-full text-sm text-left">
                   <thead className="bg-zinc-50/50 dark:bg-zinc-800/50 text-zinc-500 dark:text-zinc-400 uppercase text-xs font-bold border-b border-zinc-200 dark:border-zinc-700">
                     <tr>
                       <th className="px-6 py-4">Aluno</th>
                       <th className="px-6 py-4 w-32 text-center">Prova 1</th>
                       <th className="px-6 py-4 w-32 text-center">Trabalho</th>
                       <th className="px-6 py-4 w-32 text-center">Conceito</th>
                       <th className="px-6 py-4 text-center">Média Final</th>
                     </tr>
                   </thead>
                   <tbody>
                     {students.length > 0 ? students.map((student) => (
                       <tr key={student.id} className="border-b border-zinc-100 dark:border-zinc-700/50 hover:bg-zinc-50/50 dark:hover:bg-zinc-800/50 transition">
                         <td className="px-6 py-4 font-medium text-zinc-900 dark:text-zinc-200">{student.name}</td>
                         <td className="px-6 py-4">
                           <input type="number" max="10" min="0" className="w-full bg-white/50 dark:bg-zinc-900/50 border border-zinc-300 dark:border-zinc-600 rounded-lg px-2 py-1.5 text-center dark:text-white focus:ring-2 focus:ring-blue-500 outline-none" placeholder="-" />
                         </td>
                         <td className="px-6 py-4">
                            <input type="number" max="10" min="0" className="w-full bg-white/50 dark:bg-zinc-900/50 border border-zinc-300 dark:border-zinc-600 rounded-lg px-2 py-1.5 text-center dark:text-white focus:ring-2 focus:ring-blue-500 outline-none" placeholder="-" />
                         </td>
                         <td className="px-6 py-4 text-center">
                            <select className="bg-white/50 dark:bg-zinc-900/50 border border-zinc-300 dark:border-zinc-600 rounded-lg px-2 py-1.5 text-xs dark:text-white outline-none">
                              <option value="">Selecione</option>
                              <option>Pleno</option>
                              <option>Satisfatório</option>
                              <option>Em evolução</option>
                            </select>
                         </td>
                         <td className="px-6 py-4 text-center font-bold text-zinc-700 dark:text-zinc-300">
                            -
                         </td>
                       </tr>
                     )) : (
                         <tr>
                             <td colSpan={5} className="px-6 py-8 text-center text-zinc-500">
                                 Nenhum aluno para avaliar nesta turma.
                             </td>
                         </tr>
                     )}
                   </tbody>
                 </table>
               </div>
           )}

           <div className="p-4 bg-zinc-50/30 dark:bg-zinc-800/30 border-t border-zinc-200 dark:border-zinc-700 flex justify-end gap-2">
             <button onClick={handlePrint} className="px-4 py-2.5 text-zinc-600 dark:text-zinc-400 bg-white dark:bg-zinc-800 rounded-xl text-sm font-medium hover:bg-zinc-50 border border-zinc-200 dark:border-zinc-600 transition">
                Relatório de Notas
             </button>
             <button 
               onClick={() => showToast('Notas Atualizadas', 'Lançamento efetuado com sucesso!', 'success')}
               className="px-6 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700 shadow-lg shadow-blue-500/30 transition"
               disabled={students.length === 0}
             >
               Salvar Notas
             </button>
           </div>
        </div>
      )}
    </div>
  );
};

export default ProfessorTools;