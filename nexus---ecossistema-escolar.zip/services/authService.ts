import { supabase } from '../lib/supabaseClient';
import { User, Student, UserRole } from '../types';

export const loginInstitutional = async (identifier: string, secretariatId: string, password?: string): Promise<User | null> => {
  try {
    // 1. Verificar se a secretaria está ativa
    const { data: secData, error: secError } = await supabase
        .from('secretariats')
        .select('active')
        .eq('id', secretariatId)
        .single();
    
    // Note: If connection fails, we might want to skip this check or rely on offline mode.
    // For now, if explicit error regarding active status exists, we return null.
    if (secData && secData.active === false) {
        console.warn('Login bloqueado: Secretaria inativa.');
        return null;
    }

    // --- TENTATIVA 1: Login via Perfil de Usuário (E-mail) ---
    const { data: profileData } = await supabase
      .from('profiles')
      .select('*')
      .eq('email', identifier)
      .eq('secretariat_id', secretariatId)
      .maybeSingle();

    if (profileData) {
        // Validação de senha do perfil
        if (profileData.password && profileData.password !== password) {
            console.warn('Senha incorreta (Perfil).');
            return null;
        }

        return {
            id: profileData.id,
            name: profileData.name,
            email: profileData.email,
            role: profileData.role,
            secretariatId: profileData.secretariat_id,
            schoolId: profileData.school_id || undefined,
            avatarUrl: profileData.avatar_url || undefined
        };
    }

    // --- TENTATIVA 2: Login via Entidade Escolar (INEP) ---
    // Se não achou usuário por e-mail, tenta achar escola pelo INEP
    const { data: schoolData } = await supabase
      .from('schools')
      .select('*')
      .eq('inep', identifier)
      .eq('secretariat_id', secretariatId)
      .maybeSingle();

    if (schoolData) {
        // Verifica se a escola está ativa
        if (schoolData.active === false) {
            console.warn('Login bloqueado: Escola inativa.');
            return null;
        }

        // Validação de senha da escola
        if (schoolData.password && schoolData.password !== password) {
            console.warn('Senha incorreta (Escola).');
            return null;
        }

        // Retorna um usuário "sintético" representando a gestão da escola
        return {
            id: `school-admin-${schoolData.id}`,
            name: `Gestão - ${schoolData.name}`,
            email: schoolData.email || `${schoolData.inep}@escola.sistema`,
            role: UserRole.GESTOR, // Assume papel de Gestor
            secretariatId: schoolData.secretariat_id,
            schoolId: schoolData.id,
            avatarUrl: undefined
        };
    }

    return null;

  } catch (err) {
    console.error('Erro inesperado no serviço de autenticação:', err);
    return null;
  }
};

export const loginStudent = async (matricula: string, birthDate: string, secretariatId: string, schoolId: string): Promise<Student | null> => {
  try {
    // Verificar se a secretaria está ativa
    const { data: secData } = await supabase.from('secretariats').select('active').eq('id', secretariatId).single();
    if (secData && secData.active === false) return null;

    // Verificar se a escola está ativa
    const { data: schoolData } = await supabase.from('schools').select('active').eq('id', schoolId).single();
    if (schoolData && schoolData.active === false) return null;

    const { data, error } = await supabase
      .from('students')
      .select('*')
      .eq('matricula', matricula)
      .eq('birth_date', birthDate)
      .eq('secretariat_id', secretariatId)
      .eq('school_id', schoolId)
      .maybeSingle();

    if (error || !data) {
      return null;
    }

    return {
      id: data.id,
      matricula: data.matricula,
      name: data.name,
      birthDate: data.birth_date,
      schoolId: data.school_id,
      secretariatId: data.secretariat_id,
      className: data.class_name
    };
  } catch (err) {
    console.error('Erro inesperado:', err);
    return null;
  }
};