import { supabase } from '../lib/supabaseClient';
import { School, User, Student, Secretariat } from '../types';
import { SECRETARIATS } from '../constants';

// --- SECRETARIAS (SUPER ADMIN) ---

export const getAllSecretariats = async (): Promise<(Secretariat & { adminEmail?: string })[]> => {
    const { data: secData, error: secError } = await supabase
        .from('secretariats')
        .select('*')
        .order('name');
    
    if (secError) {
        console.error('SUPABASE ERROR (Get Secretariats):', secError.message);
        // Fallback to mock data to ensure app functionality when offline/error
        return SECRETARIATS.map(s => ({
            ...s,
            adminEmail: 'admin@demo.com' // Mock admin email
        }));
    }

    const { data: profilesData } = await supabase
        .from('profiles')
        .select('email, secretariat_id')
        .eq('role', 'SECRETARIA');

    return secData.map((s: any) => {
        const adminProfile = profilesData?.find((p: any) => p.secretariat_id === s.id);
        return {
            id: s.id,
            name: s.name,
            state: s.state,
            city: s.city,
            logoUrl: s.logo_url,
            active: s.active !== false,
            adminEmail: adminProfile ? adminProfile.email : undefined
        };
    });
};

export const saveSecretariat = async (
    secretariat: Secretariat, 
    adminEmail: string, 
    adminPassword: string | null,
    isUpdate: boolean
): Promise<{ success: boolean; message?: string }> => {
    
    // 1. Salvar/Atualizar a Secretaria
    const secPayload = {
        id: secretariat.id,
        name: secretariat.name,
        state: secretariat.state,
        city: secretariat.city,
        logo_url: secretariat.logoUrl,
        active: secretariat.active
    };

    const { error: secError } = await supabase
        .from('secretariats')
        .upsert(secPayload);
    
    if (secError) {
        return { success: false, message: `Erro ao salvar entidade: ${secError.message}` };
    }

    // 2. Gerenciar o Usuário Admin
    if (adminEmail) {
        const { data: existingAdmin } = await supabase
            .from('profiles')
            .select('id')
            .eq('secretariat_id', secretariat.id)
            .eq('role', 'SECRETARIA')
            .maybeSingle();

        const profileId = existingAdmin ? existingAdmin.id : `u-admin-${secretariat.id}`;
        
        const profilePayload: any = {
            id: profileId,
            name: `Secretário(a) - ${secretariat.city}`,
            email: adminEmail,
            role: 'SECRETARIA',
            secretariat_id: secretariat.id,
        };

        if (adminPassword && adminPassword.trim() !== '') {
            profilePayload.password = adminPassword; 
        }

        const { error: profileError } = await supabase
            .from('profiles')
            .upsert(profilePayload);

        if (profileError) {
            return { success: true, message: 'Secretaria salva, mas houve erro ao atualizar as credenciais do admin.' };
        }
    }

    return { success: true };
};

export const toggleSecretariatStatus = async (id: string, currentStatus: boolean): Promise<boolean> => {
    const { error } = await supabase
        .from('secretariats')
        .update({ active: !currentStatus })
        .eq('id', id);
    
    if (error) {
        console.error('SUPABASE ERROR (Toggle Secretariat):', error.message);
        return false;
    }
    return true;
};

// --- ESCOLAS ---

export const getSchoolsBySecretariat = async (secretariatId: string): Promise<School[]> => {
  const { data, error } = await supabase
    .from('schools')
    .select('*')
    .eq('secretariat_id', secretariatId)
    .order('name');

  if (error) {
    console.error('Erro ao buscar escolas:', error);
    return [];
  }
  
  return data.map((s: any) => ({
    id: s.id,
    secretariatId: s.secretariat_id,
    name: s.name,
    inep: s.inep,
    password: s.password,
    active: s.active,
    // Novos campos
    address: s.address,
    phone: s.phone,
    email: s.email,
    locationZone: s.location_zone,
    stages: s.stages,
    modalities: s.modalities,
    // Equipe Gestora
    managerName: s.manager_name,
    viceManagerName: s.vice_manager_name,
    coordinatorName: s.coordinator_name
  }));
};

export const saveSchool = async (school: School): Promise<{success: boolean, message?: string}> => {
    const payload: any = {
        id: school.id,
        secretariat_id: school.secretariatId,
        name: school.name,
        inep: school.inep,
        active: school.active,
        // Novos campos
        address: school.address,
        phone: school.phone,
        email: school.email,
        location_zone: school.locationZone,
        stages: school.stages,
        modalities: school.modalities,
        // Equipe Gestora
        manager_name: school.managerName,
        vice_manager_name: school.viceManagerName,
        coordinator_name: school.coordinatorName
    };

    if (school.password) {
        payload.password = school.password;
    }

    const { error } = await supabase.from('schools').upsert(payload);

    if (error) {
        if (error.code === '23505') return { success: false, message: 'Já existe uma escola com este código INEP.' };
        return { success: false, message: error.message };
    }
    return { success: true };
};

export const toggleSchoolStatus = async (schoolId: string, currentStatus: boolean): Promise<boolean> => {
    const { error } = await supabase
        .from('schools')
        .update({ active: !currentStatus })
        .eq('id', schoolId);
    
    return !error;
};

// --- USUÁRIOS & ESTATÍSTICAS ---

export const getSchoolStats = async (schoolId: string) => {
    try {
        const [studentsReq, professorsReq] = await Promise.all([
            supabase.from('students').select('id', { count: 'exact' }).eq('school_id', schoolId),
            supabase.from('profiles').select('*').eq('school_id', schoolId).eq('role', 'PROFESSOR')
        ]);

        const professors: User[] = (professorsReq.data || []).map((p: any) => ({
             id: p.id, 
             name: p.name, 
             email: p.email, 
             role: p.role, 
             secretariatId: p.secretariat_id, 
             schoolId: p.school_id,
             avatarUrl: p.avatar_url
        }));

        return {
            studentCount: studentsReq.count || 0,
            professors
        };
    } catch (error) {
        console.error("Erro ao buscar estatísticas:", error);
        return { studentCount: 0, professors: [] };
    }
};

export const getFullSchoolAudit = async (schoolId: string) => {
    try {
        const [school, students, profiles] = await Promise.all([
            supabase.from('schools').select('*').eq('id', schoolId).single(),
            supabase.from('students').select('*').eq('school_id', schoolId),
            supabase.from('profiles').select('*').eq('school_id', schoolId)
        ]);

        return {
            school: school.data,
            students: students.data || [],
            staff: profiles.data || []
        };
    } catch (error) {
        console.error('Erro na auditoria:', error);
        return null;
    }
};

export const getStudentsByClass = async (schoolId: string, className: string): Promise<Student[]> => {
    const { data, error } = await supabase
        .from('students')
        .select('*')
        .eq('school_id', schoolId)
        .eq('class_name', className)
        .order('name');

    if (error) return [];

    return data.map((s: any) => ({
        id: s.id,
        matricula: s.matricula,
        name: s.name,
        birthDate: s.birth_date,
        schoolId: s.school_id,
        secretariatId: s.secretariat_id,
        className: s.class_name
    }));
};