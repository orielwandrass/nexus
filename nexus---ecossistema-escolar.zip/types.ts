export enum UserRole {
  SECRETARIA = 'SECRETARIA',
  GESTOR = 'GESTOR',
  COORDENADOR = 'COORDENADOR',
  PROFESSOR = 'PROFESSOR',
  ALUNO = 'ALUNO',
  SUPER_ADMIN = 'SUPER_ADMIN'
}

export interface Secretariat {
  id: string;
  name: string;
  state: string;
  city: string;
  logoUrl?: string;
  active: boolean;
}

export interface School {
  id: string;
  secretariatId: string;
  name: string;
  inep: string;
  password?: string;
  active: boolean;
  // Campos de Contato e Caracterização
  address?: string;
  phone?: string;
  email?: string;
  locationZone?: 'Urbana' | 'Rural';
  stages?: string[]; // Ex: ['Ensino Fundamental Anos Iniciais', 'Ensino Fundamental Anos Finais']
  modalities?: string[]; // Ex: ['Ensino Regular', 'EJA']
  // Campos de Equipe Gestora
  managerName?: string;
  viceManagerName?: string;
  coordinatorName?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  secretariatId: string;
  schoolId?: string;
  avatarUrl?: string;
}

export interface Student {
  id: string;
  matricula: string;
  name: string;
  birthDate: string; // YYYY-MM-DD
  schoolId: string;
  secretariatId: string;
  className: string;
}

export interface DiaryEntry {
  id: string;
  date: string;
  subject: string;
  content: string;
  methodology: string;
  bnccCodes: string[];
  professorId: string;
  schoolId: string;
  className: string;
}

export interface Grade {
  studentId: string;
  subject: string;
  period: number;
  value: number;
  type: 'NOTA' | 'CONCEITO';
}

export interface Attendance {
  studentId: string;
  date: string;
  present: boolean;
}

export interface Subject {
  id: string;
  name: string;
}