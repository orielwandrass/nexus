import { Secretariat, School, User, UserRole, Student, Subject, DiaryEntry, Grade, Attendance } from './types';

// 1. Secretariats (Tenants)
export const SECRETARIATS: Secretariat[] = [
  { id: 'sec-smect', name: 'Secretaria Municipal de Educação, Ciências e Tecnologia', state: 'MA', city: 'Caxias', logoUrl: 'https://picsum.photos/id/3/200/200', active: true },
  { id: 'sec-brejao', name: 'Secretaria Municipal de Educação de São Francisco do Brejão', state: 'MA', city: 'São Francisco do Brejão', logoUrl: 'https://picsum.photos/id/10/200/200', active: true },
];

// 2. Schools
export const SCHOOLS: School[] = [
  // Caxias
  { id: 'sch-4', secretariatId: 'sec-smect', name: 'Escola Modelo de Tecnologia', inep: '99887766', active: true },
  { id: 'sch-5', secretariatId: 'sec-smect', name: 'C.E.I. Pequeno Príncipe', inep: '55443322', active: false },
  // Brejão
  { id: 'sch-brejao-1', secretariatId: 'sec-brejao', name: 'Escola Municipal Tobias Barreto', inep: '21005544', active: true },
];

// 3. Users (Auth)
export const USERS: User[] = [
  // SUPER ADMIN
  { id: 'u-super-admin', name: 'Oriel Wandrass Costa da Silva', email: 'wnd4521x', role: UserRole.SUPER_ADMIN, secretariatId: 'sec-smect' },

  // Admin Caxias
  { id: 'u-sec-2', name: 'Carlos Mendes (Secretário)', email: 'admin@smect.gov.br', role: UserRole.SECRETARIA, secretariatId: 'sec-smect' },
  
  // Gestor Nova Escola
  { id: 'u-ges-2', name: 'Fernanda Costa (Diretora)', email: 'diretora@modelo.smect.gov.br', role: UserRole.GESTOR, secretariatId: 'sec-smect', schoolId: 'sch-4' },
  
  // Coordenador Nova Escola
  { id: 'u-coord-1', name: 'Juliana Paes (Coordenadora)', email: 'coord@modelo.smect.gov.br', role: UserRole.COORDENADOR, secretariatId: 'sec-smect', schoolId: 'sch-4' },

  // Professor Nova Escola
  { id: 'u-prof-2', name: 'Ricardo Alves (Professor)', email: 'prof@modelo.smect.gov.br', role: UserRole.PROFESSOR, secretariatId: 'sec-smect', schoolId: 'sch-4' },
  { id: 'u-prof-caxias-demo', name: 'Professor Demo Caxias', email: 'prof.caxias@smect.gov.br', role: UserRole.PROFESSOR, secretariatId: 'sec-smect', schoolId: 'sch-4' }
];

// 4. Students
export const STUDENTS: Student[] = [
  { id: 'st-3', matricula: '2024999', name: 'Pedro Henrique Santos', birthDate: '2010-01-15', schoolId: 'sch-4', secretariatId: 'sec-smect', className: '9º Ano B' },
  { id: 'st-demo-caxias', matricula: '2024-CAX-01', name: 'Aluno Teste Caxias', birthDate: '2015-02-10', schoolId: 'sch-4', secretariatId: 'sec-smect', className: '5º Ano A' }
];

// 5. Educational Data
export const SUBJECTS: Subject[] = [
  { id: 'math', name: 'Matemática' },
  { id: 'port', name: 'Língua Portuguesa' },
  { id: 'sci', name: 'Ciências' },
  { id: 'hist', name: 'História' },
  { id: 'geo', name: 'Geografia' },
  { id: 'tec', name: 'Robótica e Tecnologia' }, 
];

export const MOCK_DIARY: DiaryEntry[] = []; // Dados movidos para banco

export const MOCK_GRADES: Grade[] = [
  { studentId: 'st-3', subject: 'Robótica e Tecnologia', period: 1, value: 10.0, type: 'NOTA' },
];

export const MOCK_ATTENDANCE: Attendance[] = [
  { studentId: 'st-3', date: '2024-03-10', present: true },
];

export const BNCC_SKILLS = [
  { code: 'EF05MA03', description: 'Identificar e representar frações.' },
  { code: 'EF05MA04', description: 'Identificar frações equivalentes.' },
  { code: 'EF15LP01', description: 'Compreender a função social de textos.' },
  { code: 'EF09TC01', description: 'Compreender algoritmos e lógica de programação.' },
];