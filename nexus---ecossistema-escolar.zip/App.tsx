import React, { useState, useEffect } from 'react';
import { User, Student, UserRole } from './types';
import { SECRETARIATS, SCHOOLS } from './constants';
import * as AuthService from './services/authService';
import { getAllSecretariats } from './services/dataService'; // Import necessário para busca dinâmica
import ProfessorTools from './components/ProfessorTools';
import StudentPortal from './components/StudentPortal';
import SecretariatDashboard from './components/SecretariatDashboard';
import SchoolManagerDashboard from './components/SchoolManagerDashboard';
import SuperAdminDashboard from './components/SuperAdminDashboard';
import Modal from './components/ui/Modal';
import { MorphingText } from './components/ui/MorphingText';
import { 
  Book, Users, School as SchoolIcon, LayoutDashboard, LogOut, 
  ShieldCheck, ChevronRight, Search, Moon, Sun, MapPin, 
  Briefcase, GraduationCap, ArrowLeft, PenTool, Calculator, Microscope, Globe,
  LockKeyhole
} from 'lucide-react';

const App: React.FC = () => {
  // Theme State
  const [darkMode, setDarkMode] = useState(false);

  // Auth State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // Data State (Para busca dinâmica)
  const [activeSecretariats, setActiveSecretariats] = useState<any[]>([]);
  
  // Navigation & Form State
  const [selectedSecretariatId, setSelectedSecretariatId] = useState<string>('');
  const [loginStep, setLoginStep] = useState<'SEARCH' | 'PROFILE_SELECT' | 'FORM' | 'ADMIN_LOGIN'>('SEARCH');
  const [selectedProfileType, setSelectedProfileType] = useState<'STAFF' | 'STUDENT' | null>(null);
  
  // Search State
  const [searchQuery, setSearchQuery] = useState('');

  // Form Inputs
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState(''); // Novo campo de senha
  const [matricula, setMatricula] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [schoolIdForLogin, setSchoolIdForLogin] = useState('');

  // Admin Inputs
  const [adminLogin, setAdminLogin] = useState('');
  const [adminPassword, setAdminPassword] = useState('');

  // Modal State
  const [modalConfig, setModalConfig] = useState<{isOpen: boolean, title: string, message: string, type: 'success' | 'error' | 'info'}>({
    isOpen: false, title: '', message: '', type: 'info'
  });

  const selectedSecretariat = activeSecretariats.find(s => s.id === selectedSecretariatId) || SECRETARIATS.find(s => s.id === selectedSecretariatId);

  // Toggle Dark Mode
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Carregar Secretarias Ativas
  useEffect(() => {
    const fetchSecs = async () => {
        const secs = await getAllSecretariats();
        // Filtra apenas as ativas para exibição pública
        setActiveSecretariats(secs.filter(s => s.active));
    };
    fetchSecs();
  }, [loginStep]); // Recarrega se voltar para a busca

  const showModal = (title: string, message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setModalConfig({ isOpen: true, title, message, type });
  };

  const closeModal = () => {
    setModalConfig(prev => ({ ...prev, isOpen: false }));
  };

  // Reset function
  const resetLoginFlow = () => {
      setSelectedSecretariatId('');
      setLoginStep('SEARCH');
      setSelectedProfileType(null);
      setEmail('');
      setPassword('');
      setMatricula('');
      setBirthDate('');
      setAdminLogin('');
      setAdminPassword('');
  };

  const handleSecretariatSelect = (id: string) => {
      setSelectedSecretariatId(id);
      setLoginStep('PROFILE_SELECT');
  };

  const handleProfileSelect = (type: 'STAFF' | 'STUDENT') => {
      setSelectedProfileType(type);
      setLoginStep('FORM');
  };

  const handleInstitutionalLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      // Passa a senha agora
      const user = await AuthService.loginInstitutional(email, selectedSecretariatId, password);
      if (user) {
        setCurrentUser(user);
      } else {
        showModal('Erro de Acesso', 'Credenciais inválidas. Verifique E-mail/INEP e Senha.', 'error');
      }
    } catch (error) {
      showModal('Erro de Conexão', 'Não foi possível conectar ao servidor.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleStudentLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const student = await AuthService.loginStudent(matricula, birthDate, selectedSecretariatId, schoolIdForLogin);
      if (student) {
        setCurrentStudent(student);
      } else {
        showModal('Aluno não encontrado', 'Verifique a Matrícula, Data de Nascimento e a Escola selecionada.', 'error');
      }
    } catch (error) {
      showModal('Erro de Conexão', 'Não foi possível conectar ao servidor.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuperAdminLogin = (e: React.FormEvent) => {
      e.preventDefault();
      setIsLoading(true);
      if (adminLogin === 'wnd4521x' && adminPassword === '984521') {
          setCurrentUser({
              id: 'u-super-admin',
              name: 'Oriel Wandrass Costa da Silva',
              email: 'wnd4521x',
              role: UserRole.SUPER_ADMIN,
              secretariatId: 'GLOBAL'
          });
      } else {
          showModal('Acesso Negado', 'Credenciais de administrador incorretas.', 'error');
      }
      setIsLoading(false);
  };

  const logout = () => {
    setCurrentUser(null);
    setCurrentStudent(null);
    resetLoginFlow();
  };

  // Filtered Secretariats logic
  const hasSearch = searchQuery.length > 0;
  // Usa o state activeSecretariats (do banco) em vez da constante estática
  const filteredSecretariats = hasSearch ? activeSecretariats.filter(sec => {
    const query = searchQuery.toLowerCase();
    return sec.name.toLowerCase().includes(query) || 
           sec.state.toLowerCase().includes(query) ||
           (sec.city && sec.city.toLowerCase().includes(query)); 
  }) : [];

  const EducationBackground = () => (
    <div className="fixed inset-0 overflow-hidden pointer-events-none -z-10">
      <div className={`absolute top-0 left-1/4 w-96 h-96 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob ${darkMode ? 'bg-indigo-900' : 'bg-purple-300'}`}></div>
      <div className={`absolute top-0 right-1/4 w-96 h-96 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000 ${darkMode ? 'bg-blue-900' : 'bg-yellow-300'}`}></div>
      <div className={`absolute -bottom-32 left-1/3 w-96 h-96 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-4000 ${darkMode ? 'bg-purple-900' : 'bg-pink-300'}`}></div>
      <div className={`absolute inset-0 ${darkMode ? 'bg-zinc-950/95' : 'bg-zinc-50/50'}`}></div>

      <div className="absolute top-20 left-10 opacity-[0.03] dark:opacity-[0.05] animate-float text-zinc-900 dark:text-white">
        <Book size={120} />
      </div>
      <div className="absolute top-40 right-20 opacity-[0.03] dark:opacity-[0.05] animate-float-delayed text-zinc-900 dark:text-white">
        <GraduationCap size={140} />
      </div>
      <div className="absolute bottom-20 left-1/4 opacity-[0.03] dark:opacity-[0.05] animate-float text-zinc-900 dark:text-white">
        <PenTool size={100} />
      </div>
      <div className="absolute top-1/2 left-20 opacity-[0.02] dark:opacity-[0.04] animate-float-delayed text-zinc-900 dark:text-white">
        <Calculator size={80} />
      </div>
      <div className="absolute bottom-40 right-1/3 opacity-[0.03] dark:opacity-[0.05] animate-float text-zinc-900 dark:text-white">
        <Microscope size={110} />
      </div>
      <div className="absolute top-1/3 right-10 opacity-[0.02] dark:opacity-[0.04] animate-float-delayed text-zinc-900 dark:text-white">
        <Globe size={90} />
      </div>
    </div>
  );

  // --- RENDER LOGIC ---

  if (currentUser?.role === UserRole.SUPER_ADMIN) {
      return (
          <>
            <SuperAdminDashboard user={currentUser} showToast={showModal} onLogout={logout} />
            <Modal {...modalConfig} onClose={closeModal} />
          </>
      );
  }

  if (currentStudent) {
    return (
      <div className={darkMode ? 'dark' : ''}>
         <EducationBackground />
         <StudentPortal student={currentStudent} onLogout={logout} darkMode={darkMode} />
         <Modal {...modalConfig} onClose={closeModal} />
      </div>
    );
  }

  if (currentUser) {
    const userSchool = SCHOOLS.find(s => s.id === currentUser.schoolId);
    const userSecretariat = activeSecretariats.find(s => s.id === currentUser.secretariatId) || SECRETARIATS.find(s => s.id === currentUser.secretariatId);

    return (
      <div className={`min-h-screen flex text-zinc-900 dark:text-zinc-100 ${darkMode ? 'dark' : ''}`}>
        <EducationBackground />
        
        <aside className="w-64 glass-card border-r border-white/20 dark:border-zinc-800 flex flex-col fixed h-full z-10">
          <div className="p-6 border-b border-zinc-200/20 dark:border-zinc-800/50">
            <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-indigo-600 dark:from-blue-400 dark:to-indigo-400 bg-clip-text text-transparent">NEXUS</h1>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 truncate">{userSecretariat?.city} - {userSecretariat?.state}</p>
          </div>
          
          <nav className="flex-1 p-4 space-y-2">
            <div className="px-4 py-3 bg-blue-50/50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 rounded-xl flex items-center gap-3 cursor-pointer shadow-sm">
              <LayoutDashboard size={18} />
              <span className="text-sm font-semibold">Dashboard</span>
            </div>
            
            {currentUser.role === UserRole.SECRETARIA && (
              <>
                <div className="px-4 py-3 hover:bg-zinc-100/50 dark:hover:bg-zinc-800/50 rounded-xl flex items-center gap-3 cursor-pointer transition text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200">
                  <SchoolIcon size={18} />
                  <span className="text-sm font-medium">Gestão de Escolas</span>
                </div>
                <div className="px-4 py-3 hover:bg-zinc-100/50 dark:hover:bg-zinc-800/50 rounded-xl flex items-center gap-3 cursor-pointer transition text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200">
                  <ShieldCheck size={18} />
                  <span className="text-sm font-medium">Auditoria</span>
                </div>
              </>
            )}

            {(currentUser.role === UserRole.GESTOR || currentUser.role === UserRole.COORDENADOR || currentUser.role === UserRole.PROFESSOR) && (
              <>
                <div className="px-4 py-3 hover:bg-zinc-100/50 dark:hover:bg-zinc-800/50 rounded-xl flex items-center gap-3 cursor-pointer transition text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200">
                  <Users size={18} />
                  <span className="text-sm font-medium">Alunos</span>
                </div>
                <div className="px-4 py-3 hover:bg-zinc-100/50 dark:hover:bg-zinc-800/50 rounded-xl flex items-center gap-3 cursor-pointer transition text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200">
                  <Book size={18} />
                  <span className="text-sm font-medium">
                      {currentUser.role === UserRole.PROFESSOR ? 'Meus Diários' : 'Diários (Supervisão)'}
                  </span>
                </div>
              </>
            )}
          </nav>

          <div className="p-4 border-t border-zinc-200/20 dark:border-zinc-800/50">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm shadow-lg">
                {currentUser.name.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate text-zinc-800 dark:text-white">{currentUser.name}</p>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 truncate capitalize">{currentUser.role.toLowerCase()}</p>
              </div>
            </div>
            <div className="flex gap-2">
                <button 
                    onClick={() => setDarkMode(!darkMode)}
                    className="flex-1 flex items-center justify-center p-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 transition text-zinc-500 dark:text-zinc-400"
                >
                    {darkMode ? <Sun size={18} /> : <Moon size={18} />}
                </button>
                <button onClick={logout} className="flex-1 flex items-center justify-center p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 text-red-500 dark:text-red-400 transition">
                <LogOut size={18} />
                </button>
            </div>
          </div>
        </aside>

        <main className="flex-1 ml-64 p-8 overflow-y-auto">
          <header className="mb-8 flex justify-between items-end animate-fade-in-up">
            <div>
              <h2 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-zinc-800 to-zinc-600 dark:from-white dark:to-zinc-300">
                {currentUser.role === UserRole.SECRETARIA ? 'Administração Central' : 'Painel Escolar'}
              </h2>
              <p className="text-zinc-500 dark:text-zinc-400 mt-1 flex items-center gap-2">
                <MapPin size={14} />
                {userSchool ? `${userSchool.name} - INEP: ${userSchool.inep}` : userSecretariat?.name}
              </p>
            </div>
          </header>

          <div className="animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
            
            {currentUser.role === UserRole.SECRETARIA && (
                <SecretariatDashboard user={currentUser} showToast={showModal} />
            )}

            {(currentUser.role === UserRole.GESTOR || currentUser.role === UserRole.COORDENADOR) && userSchool && (
                <SchoolManagerDashboard user={currentUser} school={userSchool} showToast={showModal} />
            )}

            {currentUser.role === UserRole.PROFESSOR && userSchool && (
                <ProfessorTools user={currentUser} school={userSchool} showToast={showModal} />
            )}

          </div>
        </main>
        <Modal {...modalConfig} onClose={closeModal} />
      </div>
    );
  }

  return (
    <div className={`min-h-screen relative flex flex-col items-center justify-center p-4 transition-colors duration-500 ${darkMode ? 'dark text-white' : 'text-zinc-900'}`}>
      <EducationBackground />
      
      <div className="absolute top-6 right-6 z-20">
            <button 
              onClick={() => setDarkMode(!darkMode)}
              className="p-3 rounded-full glass hover:scale-110 transition shadow-lg text-zinc-700 dark:text-zinc-200"
          >
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
      </div>

      <div className="absolute bottom-6 right-6 z-20">
          <button 
           onClick={() => setLoginStep('ADMIN_LOGIN')}
           className="p-2 text-zinc-300 dark:text-zinc-600 hover:text-zinc-500 dark:hover:text-zinc-400 transition"
           title="Admin Access"
          >
              <LockKeyhole size={16} />
          </button>
      </div>

      {loginStep === 'ADMIN_LOGIN' && (
          <div className="glass-card rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden relative z-10 animate-fade-in-up border border-zinc-200 dark:border-zinc-700 bg-zinc-900 text-white">
              <div className="p-8 pb-4 text-center">
                  <button onClick={resetLoginFlow} className="text-xs text-zinc-400 hover:text-white mb-4 block">← Voltar</button>
                  <LockKeyhole size={32} className="mx-auto mb-4 text-emerald-500" />
                  <h2 className="text-xl font-bold">Acesso Administrativo</h2>
                  <p className="text-xs text-zinc-400 mt-2">Área restrita para gestão do SAAS</p>
              </div>
              <div className="p-8 pt-6">
                  <form onSubmit={handleSuperAdminLogin} className="space-y-4">
                      <div>
                          <label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Login</label>
                          <input type="text" value={adminLogin} onChange={e => setAdminLogin(e.target.value)} className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white focus:border-emerald-500 outline-none" autoFocus />
                      </div>
                      <div>
                          <label className="block text-xs font-bold text-zinc-500 mb-1 uppercase">Senha</label>
                          <input type="password" value={adminPassword} onChange={e => setAdminPassword(e.target.value)} className="w-full px-4 py-2 bg-zinc-800 border border-zinc-700 rounded-lg text-white focus:border-emerald-500 outline-none" />
                      </div>
                      <button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-lg transition mt-4">
                          Entrar
                      </button>
                  </form>
              </div>
          </div>
      )}

      {loginStep === 'SEARCH' && (
        <div className="max-w-4xl w-full flex flex-col items-center z-10">
            <div className="mb-12 text-center animate-fade-in-up">
                <div className="mb-6">
                    <MorphingText texts={["NEXUS"]} className="text-blue-600 dark:text-blue-400" />
                </div>
                <p className="text-xl md:text-2xl text-zinc-600 dark:text-zinc-300 max-w-2xl mx-auto leading-relaxed font-light mt-4">
                Mais do que uma plataforma, o ecossistema da sua escola.
                </p>
            </div>

            <div className="w-full max-w-2xl relative mb-12 animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
                <div className="relative group">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <Search className="text-zinc-400 group-focus-within:text-blue-500 transition-colors" />
                    </div>
                    <input 
                        type="text"
                        placeholder="Busque sua Secretaria por cidade ou estado..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-12 pr-6 py-5 rounded-2xl glass-card text-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 shadow-xl placeholder-zinc-400 text-zinc-800 dark:text-white transition-all"
                    />
                </div>
            </div>

            {hasSearch && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
                {filteredSecretariats.length > 0 ? (
                    filteredSecretariats.map((sec) => (
                        <button
                        key={sec.id}
                        onClick={() => handleSecretariatSelect(sec.id)}
                        className="glass-card p-6 rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all text-left flex items-center group border border-white/20 dark:border-zinc-700 hover:border-blue-400 dark:hover:border-blue-500 relative overflow-hidden"
                        >
                            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                            <div className="w-16 h-16 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center mr-6 group-hover:bg-blue-600 group-hover:text-white transition-colors text-blue-600 dark:text-blue-400 shadow-inner">
                                <SchoolIcon size={28} />
                            </div>
                            <div className="flex-1 z-10">
                                <h3 className="text-lg font-bold text-zinc-800 dark:text-white group-hover:text-blue-700 dark:group-hover:text-blue-300 transition-colors leading-tight">{sec.name}</h3>
                                <span className="text-xs font-semibold bg-zinc-200/50 dark:bg-zinc-700/50 px-2 py-1 rounded mt-2 inline-block text-zinc-600 dark:text-zinc-300">
                                {sec.city} - {sec.state}
                                </span>
                            </div>
                            <ChevronRight className="ml-auto text-zinc-300 dark:text-zinc-600 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
                        </button>
                    ))
                ) : (
                    <div className="col-span-2 text-center py-10 glass-card rounded-2xl">
                        <p className="text-zinc-500 dark:text-zinc-400">Nenhuma secretaria encontrada para "{searchQuery}"</p>
                    </div>
                )}
                </div>
            )}
        </div>
      )}

      {loginStep === 'PROFILE_SELECT' && (
          <div className="max-w-4xl w-full z-10 animate-fade-in-up">
              <button onClick={resetLoginFlow} className="mb-6 flex items-center gap-2 text-zinc-500 hover:text-blue-600 dark:text-zinc-400 dark:hover:text-blue-400 transition">
                  <ArrowLeft size={20} /> Voltar para a busca
              </button>
              
              <div className="text-center mb-10">
                  <h2 className="text-3xl font-bold mb-2">{selectedSecretariat?.name}</h2>
                  <p className="text-zinc-600 dark:text-zinc-300">Selecione o seu perfil de acesso ao ecossistema.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <button 
                    onClick={() => handleProfileSelect('STAFF')}
                    className="glass-card p-10 rounded-3xl hover:scale-[1.02] transition-all group border border-transparent hover:border-blue-500/30 flex flex-col items-center text-center animate-fade-in-up"
                    style={{ animationDelay: '0.1s' }}
                  >
                      <div className="w-24 h-24 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center mb-6 text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform">
                          <Briefcase size={40} />
                      </div>
                      <h3 className="text-2xl font-bold mb-3">Equipe Escolar & Gestão</h3>
                      <p className="text-zinc-500 dark:text-zinc-400 leading-relaxed">
                          Acesso restrito para Professores, Coordenadores, Gestores Escolares e Secretaria de Educação.
                      </p>
                  </button>

                  <button 
                    onClick={() => handleProfileSelect('STUDENT')}
                    className="glass-card p-10 rounded-3xl hover:scale-[1.02] transition-all group border border-transparent hover:border-emerald-500/30 flex flex-col items-center text-center animate-fade-in-up"
                    style={{ animationDelay: '0.2s' }}
                  >
                      <div className="w-24 h-24 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mb-6 text-emerald-600 dark:text-emerald-400 group-hover:scale-110 transition-transform">
                          <GraduationCap size={40} />
                      </div>
                      <h3 className="text-2xl font-bold mb-3">Estudantes & Responsáveis</h3>
                      <p className="text-zinc-500 dark:text-zinc-400 leading-relaxed">
                          Portal do Aluno para consulta de boletim, frequência e acompanhamento pedagógico.
                      </p>
                  </button>
              </div>
          </div>
      )}

      {loginStep === 'FORM' && (
        <div className="glass-card rounded-3xl shadow-2xl w-full max-w-md overflow-hidden relative z-10 animate-fade-in-up border border-white/30 dark:border-zinc-700">
            <div className="p-8 pb-4 text-center">
            <button 
                onClick={() => setLoginStep('PROFILE_SELECT')} 
                className="text-xs text-blue-600 dark:text-blue-400 hover:underline mb-4 block font-medium"
            >
                ← Escolher outro perfil
            </button>
            <div className={`w-16 h-16 mx-auto rounded-2xl flex items-center justify-center shadow-lg mb-4 text-white ${selectedProfileType === 'STAFF' ? 'bg-gradient-to-br from-blue-500 to-indigo-600' : 'bg-gradient-to-br from-emerald-500 to-teal-600'}`}>
                {selectedProfileType === 'STAFF' ? <Briefcase size={32} /> : <GraduationCap size={32} />}
            </div>
            <h2 className="text-xl font-bold text-zinc-800 dark:text-white leading-tight">
                {selectedProfileType === 'STAFF' ? 'Acesso Administrativo' : 'Portal do Aluno'}
            </h2>
            <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-2">{selectedSecretariat?.name}</p>
            </div>

            <div className="p-8 pt-6">
            {selectedProfileType === 'STAFF' ? (
                <form onSubmit={handleInstitutionalLogin} className="space-y-4">
                <div>
                    <label className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 mb-1 uppercase tracking-wider">E-mail Institucional ou Código INEP</label>
                    <input 
                    type="text" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 bg-white/50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition dark:text-white font-medium"
                    placeholder="seu.email@gov.br ou 00000000"
                    required
                    />
                </div>
                <div>
                    <label className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 mb-1 uppercase tracking-wider">Senha</label>
                    <input 
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-4 py-3 bg-white/50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition dark:text-white"
                    placeholder="••••••••"
                    required
                    />
                </div>
                <button 
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-lg hover:shadow-blue-600/30 transform hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                    {isLoading ? (
                      <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : 'Acessar NEXUS'}
                </button>
                </form>
            ) : (
                <form onSubmit={handleStudentLogin} className="space-y-4">
                <div>
                    <label className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 mb-1 uppercase tracking-wider">Escola</label>
                    <select 
                        className="w-full px-4 py-3 bg-white/50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-600 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none dark:text-white"
                        value={schoolIdForLogin}
                        onChange={(e) => setSchoolIdForLogin(e.target.value)}
                        required
                    >
                        <option value="">Selecione sua escola...</option>
                        {SCHOOLS.filter(s => s.secretariatId === selectedSecretariatId && s.active).map(s => (
                            <option key={s.id} value={s.id}>{s.name}</option>
                        ))}
                    </select>
                </div>
                <div>
                    <label className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 mb-1 uppercase tracking-wider">Matrícula (RA)</label>
                    <input 
                    type="text" 
                    value={matricula}
                    onChange={(e) => setMatricula(e.target.value)}
                    className="w-full px-4 py-3 bg-white/50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-600 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition dark:text-white"
                    placeholder="Ex: 2024001"
                    required
                    />
                </div>
                <div>
                    <label className="block text-xs font-bold text-zinc-500 dark:text-zinc-400 mb-1 uppercase tracking-wider">Data de Nascimento</label>
                    <input 
                    type="date" 
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    className="w-full px-4 py-3 bg-white/50 dark:bg-zinc-900/50 border border-zinc-200 dark:border-zinc-600 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition dark:text-white"
                    required
                    />
                </div>
                <button 
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-lg hover:shadow-emerald-600/30 transform hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                    {isLoading ? (
                      <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : 'Acessar Boletim'}
                </button>
                </form>
            )}
            </div>
        </div>
      )}

      <Modal {...modalConfig} onClose={closeModal} />
    </div>
  );
};

export default App;