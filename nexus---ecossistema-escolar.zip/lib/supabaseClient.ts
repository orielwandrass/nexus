import { createClient } from '@supabase/supabase-js';

// ATENÇÃO: Substitua os valores abaixo pelas credenciais do seu projeto Supabase
// Você pode encontrá-las em: Project Settings > API
const supabaseUrl = 'https://jcaalbgrcfpgfwlidkhe.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpjYWFsYmdyY2ZwZ2Z3bGlka2hlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjkwMDY4MzcsImV4cCI6MjA4NDU4MjgzN30.XGLhB-bFzN9MQl6L7ZNDfm9ZeElGVZjFr3d_DrUUzvM';

export const supabase = createClient(supabaseUrl, supabaseKey);