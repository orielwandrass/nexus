-- ==============================================================================
-- SCHEMA DO BANCO DE DADOS - PROJETO NEXUS (VERSÃO DEFINITIVA)
-- ==============================================================================

-- 1. CONFIGURAÇÕES INICIAIS E EXTENSÕES
create extension if not exists "uuid-ossp";

-- Enum para Roles (cria apenas se não existir)
do $$ begin
    create type public.user_role as enum ('SECRETARIA', 'GESTOR', 'COORDENADOR', 'PROFESSOR', 'ALUNO', 'SUPER_ADMIN');
exception
    when duplicate_object then null;
end $$;

-- ==============================================================================
-- 2. CRIAÇÃO E ATUALIZAÇÃO DAS TABELAS
-- ==============================================================================

-- Tabela: Secretarias (Tenants Nível 1)
create table if not exists public.secretariats (
    id text primary key,
    name text not null,
    state text not null,
    city text not null,
    logo_url text,
    active boolean default true,
    created_at timestamp with time zone default now()
);

-- Migração de Segurança
do $$ 
begin 
    if not exists (select 1 from information_schema.columns where table_name = 'secretariats' and column_name = 'active') then
        alter table public.secretariats add column active boolean default true;
    end if; 
end $$;

-- Tabela: Escolas (Tenants Nível 2)
create table if not exists public.schools (
    id text primary key,
    secretariat_id text not null references public.secretariats(id) on delete cascade,
    name text not null,
    inep text unique not null,
    password text,
    active boolean default true,
    -- Campos de Cadastro
    address text,
    phone text,
    email text,
    location_zone text check (location_zone in ('Urbana', 'Rural')),
    stages text[], 
    modalities text[],
    -- Novos Campos de Gestão
    manager_name text,
    vice_manager_name text,
    coordinator_name text,
    created_at timestamp with time zone default now()
);

-- Migração de Segurança (Adiciona colunas se não existirem)
do $$ 
begin 
    -- Campos Básicos
    if not exists (select 1 from information_schema.columns where table_name = 'schools' and column_name = 'active') then
        alter table public.schools add column active boolean default true;
    end if;
    if not exists (select 1 from information_schema.columns where table_name = 'schools' and column_name = 'password') then
        alter table public.schools add column password text;
    end if;
    
    -- Novos Campos de Contato e Caracterização
    if not exists (select 1 from information_schema.columns where table_name = 'schools' and column_name = 'address') then
        alter table public.schools add column address text;
    end if;
    if not exists (select 1 from information_schema.columns where table_name = 'schools' and column_name = 'phone') then
        alter table public.schools add column phone text;
    end if;
    if not exists (select 1 from information_schema.columns where table_name = 'schools' and column_name = 'email') then
        alter table public.schools add column email text;
    end if;
    if not exists (select 1 from information_schema.columns where table_name = 'schools' and column_name = 'location_zone') then
        alter table public.schools add column location_zone text;
    end if;
    if not exists (select 1 from information_schema.columns where table_name = 'schools' and column_name = 'stages') then
        alter table public.schools add column stages text[];
    end if;
    if not exists (select 1 from information_schema.columns where table_name = 'schools' and column_name = 'modalities') then
        alter table public.schools add column modalities text[];
    end if;

    -- Novos Campos de Equipe Gestora
    if not exists (select 1 from information_schema.columns where table_name = 'schools' and column_name = 'manager_name') then
        alter table public.schools add column manager_name text;
    end if;
    if not exists (select 1 from information_schema.columns where table_name = 'schools' and column_name = 'vice_manager_name') then
        alter table public.schools add column vice_manager_name text;
    end if;
    if not exists (select 1 from information_schema.columns where table_name = 'schools' and column_name = 'coordinator_name') then
        alter table public.schools add column coordinator_name text;
    end if;
end $$;

-- Tabela: Perfis de Usuário (Staff)
create table if not exists public.profiles (
    id text primary key,
    name text not null,
    email text unique not null,
    password text,
    role user_role not null,
    secretariat_id text not null references public.secretariats(id) on delete cascade,
    school_id text references public.schools(id) on delete set null,
    avatar_url text,
    created_at timestamp with time zone default now()
);

-- Migração de Segurança
do $$ 
begin 
    if not exists (select 1 from information_schema.columns where table_name = 'profiles' and column_name = 'password') then
        alter table public.profiles add column password text;
    end if; 
end $$;

-- Tabela: Alunos
create table if not exists public.students (
    id text primary key,
    matricula text not null,
    name text not null,
    birth_date date not null,
    school_id text not null references public.schools(id) on delete cascade,
    secretariat_id text not null references public.secretariats(id) on delete cascade,
    class_name text not null,
    created_at timestamp with time zone default now(),
    unique(matricula, school_id)
);

-- Tabela: Disciplinas
create table if not exists public.subjects (
    id text primary key,
    name text not null
);

-- Tabela: Diário de Classe
create table if not exists public.diary_entries (
    id text primary key,
    date date not null,
    subject_id text not null references public.subjects(id),
    content text not null,
    methodology text not null,
    bncc_codes text[],
    professor_id text not null references public.profiles(id),
    school_id text not null references public.schools(id),
    class_name text not null,
    created_at timestamp with time zone default now()
);

-- Tabela: Notas
create table if not exists public.grades (
    id uuid default uuid_generate_v4() primary key,
    student_id text not null references public.students(id) on delete cascade,
    subject_id text not null references public.subjects(id),
    period integer not null,
    value numeric(4,2) not null,
    type text check (type in ('NOTA', 'CONCEITO')) not null,
    created_at timestamp with time zone default now()
);

-- Tabela: Frequência
create table if not exists public.attendance (
    id uuid default uuid_generate_v4() primary key,
    student_id text not null references public.students(id) on delete cascade,
    date date not null,
    present boolean default false,
    created_at timestamp with time zone default now(),
    unique(student_id, date)
);

-- ==============================================================================
-- 3. SEGURANÇA (RLS e POLICIES)
-- ==============================================================================

alter table public.secretariats enable row level security;
alter table public.schools enable row level security;
alter table public.profiles enable row level security;
alter table public.students enable row level security;
alter table public.diary_entries enable row level security;
alter table public.grades enable row level security;
alter table public.attendance enable row level security;

-- Policies: Secretarias
drop policy if exists "Public Read Access" on public.secretariats;
create policy "Public Read Access" on public.secretariats for select using (true);

drop policy if exists "Public Write Access" on public.secretariats;
create policy "Public Write Access" on public.secretariats for all using (true);

-- Policies: Escolas
drop policy if exists "Public Read Access" on public.schools;
create policy "Public Read Access" on public.schools for select using (true);

drop policy if exists "Public Write Access" on public.schools;
create policy "Public Write Access" on public.schools for all using (true);

-- Policies: Profiles
drop policy if exists "Public Read Access" on public.profiles;
create policy "Public Read Access" on public.profiles for select using (true);

drop policy if exists "Public Write Access" on public.profiles;
create policy "Public Write Access" on public.profiles for all using (true);

-- Policies: Outras tabelas (Leitura Pública para Demo)
drop policy if exists "Public Read Access" on public.subjects;
create policy "Public Read Access" on public.subjects for select using (true);

drop policy if exists "Public Read Access" on public.students;
create policy "Public Read Access" on public.students for select using (true);

drop policy if exists "Public Read Access" on public.diary_entries;
create policy "Public Read Access" on public.diary_entries for select using (true);

drop policy if exists "Public Read Access" on public.grades;
create policy "Public Read Access" on public.grades for select using (true);

drop policy if exists "Public Read Access" on public.attendance;
create policy "Public Read Access" on public.attendance for select using (true);


-- ==============================================================================
-- 4. DADOS INICIAIS (SEED DATA)
-- ==============================================================================

-- [REMOÇÃO] Remove SP e MG para limpar o banco
DELETE FROM public.secretariats WHERE id IN ('sec-sp', 'sec-mg');

-- Inserindo Secretaria: Caxias/MA
INSERT INTO public.secretariats (id, name, state, city, logo_url, active) VALUES
('sec-smect', 'Secretaria Municipal de Educação, Ciências e Tecnologia', 'MA', 'Caxias', 'https://picsum.photos/id/3/200/200', true)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name,
    active = EXCLUDED.active;

-- Inserindo Escolas (Atualizado com novos campos de gestão)
INSERT INTO public.schools (id, secretariat_id, name, inep, active, password, address, phone, email, location_zone, stages, modalities, manager_name, vice_manager_name, coordinator_name) VALUES
('sch-4', 'sec-smect', 'Escola Modelo de Tecnologia', '99887766', true, '123456', 'Av. Central, 1000 - Centro', '(99) 3521-0000', 'escola.modelo@smect.gov.br', 'Urbana', ARRAY['Ensino Fundamental Anos Finais'], ARRAY['Ensino Regular'], 'Fernanda Costa', 'Roberto Carlos', 'Juliana Paes'),
('sch-5', 'sec-smect', 'C.E.I. Pequeno Príncipe', '55443322', false, '123456', 'Rua das Flores, 50', '(99) 3521-1111', 'cei.principe@smect.gov.br', 'Urbana', ARRAY['Ensino Fundamental Anos Iniciais'], ARRAY['Ensino Regular'], 'Ana Maria', null, 'Patricia Pillar')
ON CONFLICT (id) DO UPDATE SET 
    password = EXCLUDED.password,
    address = EXCLUDED.address,
    email = EXCLUDED.email,
    manager_name = EXCLUDED.manager_name,
    vice_manager_name = EXCLUDED.vice_manager_name,
    coordinator_name = EXCLUDED.coordinator_name;

-- Inserindo Usuários
INSERT INTO public.profiles (id, name, email, role, secretariat_id, school_id, password) VALUES
('u-sec-2', 'Carlos Mendes (Secretário)', 'admin@smect.gov.br', 'SECRETARIA', 'sec-smect', null, '123456'),
('u-ges-2', 'Fernanda Costa (Diretora)', 'diretora@modelo.smect.gov.br', 'GESTOR', 'sec-smect', 'sch-4', '123456'),
('u-coord-1', 'Juliana Paes (Coordenadora)', 'coord@modelo.smect.gov.br', 'COORDENADOR', 'sec-smect', 'sch-4', '123456'),
('u-prof-2', 'Ricardo Alves (Professor)', 'prof@modelo.smect.gov.br', 'PROFESSOR', 'sec-smect', 'sch-4', '123456')
ON CONFLICT (id) DO UPDATE SET password = EXCLUDED.password;

-- Inserindo Alunos
INSERT INTO public.students (id, matricula, name, birth_date, school_id, secretariat_id, class_name) VALUES
('st-3', '2024999', 'Pedro Henrique Santos', '2010-01-15', 'sch-4', 'sec-smect', '9º Ano B')
ON CONFLICT (id) DO NOTHING;

-- Inserindo Disciplinas
INSERT INTO public.subjects (id, name) VALUES
('math', 'Matemática'),
('port', 'Língua Portuguesa'),
('sci', 'Ciências'),
('hist', 'História'),
('geo', 'Geografia'),
('tec', 'Robótica e Tecnologia')
ON CONFLICT (id) DO NOTHING;

-- Inserindo Notas
DELETE FROM public.grades WHERE student_id = 'st-3';
INSERT INTO public.grades (student_id, subject_id, period, value, type) VALUES
('st-3', 'tec', 1, 10.0, 'NOTA');

-- Inserindo Frequência
INSERT INTO public.attendance (student_id, date, present) VALUES
('st-3', '2024-03-10', true)
ON CONFLICT (student_id, date) DO NOTHING;